#This script gets tilesets and combines them with their associated scale colorbar
library(graphics)
library(jpeg)

jet.colors <- colorRampPalette(c("#00007F", "blue", 
                                 "#007FFF", "cyan", "#7FFF7F", "yellow", "#FF7F00", 
                                 "red", "#7F0000"))
color.bar <- function(lut, min, max = -min, nticks = 11, 
                      ticks = seq(min, max, len = nticks), title = "") {
  scale <- (length(lut) - 1)/(max - min)
  # print("min is: ", min)
  # print("max is: ", max)
  plot(c(0, 10), c(min, max), type = "n", bty = "n", 
       xaxt = "n", xlab = "", yaxt = "n", ylab = "")
  mtext(title, 2, 3, cex = 1)
  axis(2, round(ticks, 0), las = .5, cex.lab = 1, cex = 10)
  for (i in 1:(length(lut) - 1)) {
    y <- (i - 1)/scale + min
    rect(0, y, 10, y + 1/scale, col = lut[i], border = NA)
  }
}

plot_jpeg = function(path, add=FALSE)
{
  require('jpeg')
  jpg = readJPEG(path, native=T) # read the file
  res = dim(jpg)[2:1] # get the resolution, [x, y]
  if (!add) # initialize an empty plot area if add==FALSE
    plot(1,1,xlim=c(1,res[1]),ylim=c(1,res[2]),asp=1,type='n',xaxs='i',yaxs='i',xaxt='n',yaxt='n',xlab='',ylab='',bty='n')
  rasterImage(jpg,1,1,res[1],res[2])
}

plot_pdf = function(path, add=FALSE)
{
  require('jpeg')
  jpg = readJPEG(path, native=T) # read the file
  res = dim(jpg)[2:1] # get the resolution, [x, y]
  if (!add) # initialize an empty plot area if add==FALSE
    plot(1,1,xlim=c(1,res[1]),ylim=c(1,res[2]),asp=1,type='n',xaxs='i',yaxs='i',xaxt='n',yaxt='n',xlab='',ylab='',bty='n')
  rasterImage(jpg,1,1,res[1],res[2])
}

tileset <- "/stor/home/mk37825/did1_l2fc_tileset.jpg"
#colorbar <- "/stor/home/mk37825/did1_padj_tileset_new_images/Rplots1.pdf"

layout_vec <- c(rep(0,10000))
count <- 0
for (i in 1:length(layout_vec)){
  if (((i %% 100) < 75)&(i %% 100 != 0)){
    layout_vec[i] <- 1
  }else if((i %% 100 < 90)&(i %% 100 > 80)&(count < 9000)&(count > 2000)){
    layout_vec[i] <- 2
  }else{
    layout_vec[i] <- 0
  }
  count <- count + 1
}

layout_matrix <- matrix(layout_vec, 100, 100, byrow = TRUE)
nf <- layout(layout_matrix)
layout.show(nf)

jpeg(filename = "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/visualizations/RRHO/tile_sets/new/did1_RRHO_l2fc.jpg", 
     width = 8, height = 8, units = "in", quality = 100, 
     res = 150)
layout_matrix <- matrix(layout_vec, 100, 100, byrow = TRUE)
nf <- layout(layout_matrix)
par(mar = c(0,0,0,0))
par(omi = c(0,0,.75,0))
plot_jpeg(tileset)
mtext("DID1 RRHO L2FC Comparisons", cex = 2)
color.bar(jet.colors(100), min = 0, max = 923, nticks = 9, title = "-log(P-value)")
dev.off()
#rasterImage(colorbar,1,1,1,1)

