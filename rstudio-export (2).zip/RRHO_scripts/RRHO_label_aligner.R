library('getopt')
library(RRHO)
defaultStepSize <-function(list1, list2){
  n1<- dim(list1)[1]
  n2<- dim(list2)[1]
  result <- ceiling(min(sqrt(c(n1,n2))))	
  return(result)
}
numericListOverlap<- function(sample1, sample2, stepsize, alternative, tol=0.5){
  n<- length(sample1)
  
  overlap<- function(a,b) {
    count<-as.integer(sum(as.numeric(sample1[1:a] %in% sample2[1:b])))
    
    switch(alternative,
           enrichment={
             log.pval<- -phyper(q=count-1, m=a, n=n-a+1, k=b, lower.tail=FALSE, log.p=TRUE)         
             signs<- 1L
           },
           two.sided={
             the.mean<- a*b/n
             signs<- sign(count - the.mean)
             if(signs < 0){
               lower<- count 
               upper<- 2*the.mean - count 
             } else{
               lower<- 2*the.mean - count 
               upper<- count 
             }
             
             log.pval<- -log(
               phyper(q=lower+tol, m=a, n=n-a+1, k=b, lower.tail=TRUE) +
                 phyper(q= upper-tol, m=a, n=n-a+1, k=b, lower.tail=FALSE))                               
           })
    
    return(c(counts=count, 
             log.pval=as.numeric(log.pval),
             signs=as.integer(signs)))    
  }
  
  
  indexes<- expand.grid(i=seq(1,n,by=stepsize), j=seq(1,n,by=stepsize))
  overlaps<- apply(indexes, 1, function(x) overlap(x['i'], x['j']))
  
  nrows<- sqrt(ncol(overlaps))
  matrix.counts<- matrix(overlaps['counts',], ncol=nrows)  
  matrix.log.pvals<- matrix(overlaps['log.pval',], ncol=nrows)  
  matrix.signs<- matrix(overlaps['signs',], ncol=nrows)  
  
  return(list(counts=matrix.counts, 
              log.pval=matrix.log.pvals,
              signs= matrix.signs))  
}

RRHO <- function (list1, list2, stepsize = defaultStepSize(list1, list2), 
          labels, alternative, plots = FALSE, outputdir = NULL, BY = FALSE, 
          log10.ind = FALSE) {
  if (length(list1[, 1]) != length(unique(list1[, 1]))) 
    stop("Non-unique gene identifier found in list1")
  if (length(list2[, 1]) != length(unique(list2[, 1]))) 
    stop("Non-unique gene identifier found in list2")
  if (plots && (missing(outputdir) || missing(labels))) 
    stop("When plots=TRUE, outputdir and labels are required.")
  if (!(alternative == "two.sided" || alternative == "enrichment")) 
    stop("Wrong alternative specified.")
  result <- list(hypermat = NA, hypermat.counts = NA, hypermat.signs = NA, 
                 hypermat.by = NA, n.items = nrow(list1), stepsize = stepsize, 
                 log10.ind = log10.ind, call = match.call())
  list1 <- list1[order(list1[, 2], decreasing = TRUE), ]
  list2 <- list2[order(list2[, 2], decreasing = TRUE), ]
  nlist1 <- length(list1[, 1])
  nlist2 <- length(list2[, 1])
  N <- max(nlist1, nlist2)
  .hypermat <- numericListOverlap(list1[, 1], list2[, 1], stepsize, 
                                  alternative)
  hypermat <- .hypermat$log.pval
  if (log10.ind) 
    hypermat <- hypermat * log10(exp(1))
  if (BY) {
    hypermatvec <- matrix(hypermat, nrow = nrow(hypermat) * 
                            ncol(hypermat), ncol = 1)
    hypermat.byvec <- p.adjust(exp(-hypermatvec), method = "BY")
    hypermat.by <- matrix(-log(hypermat.byvec), nrow = nrow(hypermat), 
                          ncol = ncol(hypermat))
    if (log10.ind) 
      hypermat.by <- hypermat.by * log10(exp(1))
    result$hypermat.by <- hypermat.by
  }
  if (plots) {
    try({
      par(mar = c(0,0,0,0))
      par(omi = c(0,0,0,0))
      hypermat.signed <- hypermat * .hypermat$signs
      #next line to get input graphing var
      #write(hypermat.signed, file = "/stor/home/mk37825/rrho.var")
      color.bar <- function(lut, min, max = -min, nticks = 11, 
                            ticks = seq(min, max, len = nticks), title = "") {
        scale <- (length(lut) - 1)/(max - min)
        # print("min is: ", min)
        # print("max is: ", max)
        plot(c(0, 10), c(min, max), type = "n", bty = "n", 
             xaxt = "n", xlab = "", yaxt = "n", ylab = "")
        mtext(title, 2, 2.3, cex = 0.8)
        axis(2, round(ticks, 0), las = 1, cex.lab = 0.8)
        for (i in 1:(length(lut) - 1)) {
          y <- (i - 1)/scale + min
          rect(0, y, 10, y + 1/scale, col = lut[i], border = NA)
        }
      }
      .filename <- paste("RRHOMap", labels[1], "_VS_", 
                         labels[2], ".jpg", sep = "")
      jpeg(filename = paste(outputdir, .filename, sep = "/"), 
           width = 8, height = 8, units = "in", quality = 100, 
           res = 150)
      par(mar = c(0,0,0,0))
      par(omi = c(0,0,0,0))
      jet.colors <- colorRampPalette(c("#00007F", "blue", 
                                       "#007FFF", "cyan", "#7FFF7F", "yellow", "#FF7F00", 
                                       "red", "#7F0000"))
      #layout(matrix(c(rep(1, 5), 2), 1, 6, byrow = TRUE))
      #ZLIM CAN BE 1023 FOR DID1, 1433 FOR DID2
      #zlim is 923 for did1 l2fc, 
      image(hypermat.signed, xlab = "", ylab = "", col = jet.colors(100), 
            axes = FALSE, zlim = c(0,923))
      mtext(labels[2], 2, 0.5)
      mtext(labels[1], 1, 0.5)
      finite.ind <- is.finite(hypermat.signed)
      ######MIN USED TO BE min(hypermat.signed[finite.ind], na.rm = TRUE)
      #color.bar(jet.colors(100), min = 0, max = 1433, nticks = 9, title = "-log(P-value)")
      dev.off()
      list2ind <- match(list1[, 1], list2[, 1])
      list1ind <- 1:nlist1
      corval <- cor(list1ind, list2ind, method = "spearman")
      .filename <- paste("RankScatter", labels[1], "_VS_", 
                         labels[2], ".jpg", sep = "")
      jpeg(paste(outputdir, .filename, sep = "/"), width = 8, 
           height = 8, units = "in", quality = 100, res = 150)
      plot(list1ind, list2ind, xlab = paste(labels[1], 
                                            "(Rank)"), ylab = paste(labels[2], "(Rank)"), 
           pch = 20, main = paste("Rank-Rank Scatter (rho = ", 
                                  signif(corval, digits = 3), ")", sep = ""), 
           cex = 0.5)
      model <- lm(list2ind ~ list1ind)
      lines(predict(model), col = "red", lwd = 3)
      dev.off()
      maxind.ur <- which(max(hypermat.signed[ceiling(nrow(hypermat.signed)/2):nrow(hypermat.signed), 
                                             ceiling(ncol(hypermat.signed)/2):ncol(hypermat.signed)], 
                             na.rm = TRUE) == hypermat.signed, arr.ind = TRUE)
      indlist1.ur <- seq(1, nlist1, stepsize)[maxind.ur[1]]
      indlist2.ur <- seq(1, nlist2, stepsize)[maxind.ur[2]]
      genelist.ur <- intersect(list1[indlist1.ur:nlist1, 
                                     1], list2[indlist2.ur:nlist2, 1])
      maxind.lr <- which(max(hypermat.signed[1:(ceiling(nrow(hypermat.signed)/2) - 
                                                  1), 1:(ceiling(ncol(hypermat.signed)/2) - 1)], 
                             na.rm = TRUE) == hypermat.signed, arr.ind = TRUE)
      indlist1.lr <- seq(1, nlist1, stepsize)[maxind.lr[1]]
      indlist2.lr <- seq(1, nlist2, stepsize)[maxind.lr[2]]
      genelist.lr <- intersect(list1[1:indlist1.lr, 1], 
                               list2[1:indlist2.lr, 1])
      .filename <- paste(outputdir, "/RRHO_GO_MostDownregulated", 
                         labels[1], "_VS_", labels[2], ".csv", sep = "")
      write.table(genelist.ur, .filename, row.names = F, 
                  quote = F, col.names = F)
      .filename <- paste(outputdir, "/RRHO_GO_MostUpregulated", 
                         labels[1], "_VS_", labels[2], ".csv", sep = "")
      write.table(genelist.lr, .filename, row.names = F, 
                  quote = F, col.names = F)
      .filename <- paste(outputdir, "/RRHO_VennMost", labels[1], 
                         "__VS__", labels[2], ".jpg", sep = "")
      jpeg(.filename, width = 8.5, height = 5, units = "in", 
           quality = 100, res = 150)
      vp1 <- viewport(x = 0.25, y = 0.5, width = 0.5, height = 0.9)
      vp2 <- viewport(x = 0.75, y = 0.5, width = 0.5, height = 0.9)
      pushViewport(vp1)
      h1 <- draw.pairwise.venn(length(indlist1.ur:nlist1), 
                               length(indlist2.ur:nlist2), length(genelist.ur), 
                               category = c(labels[1], labels[2]), scaled = TRUE, 
                               lwd = c(0, 0), fill = c("cornflowerblue", "darkorchid1"), 
                               cex = 1, cat.cex = 1.2, cat.pos = c(0, 0), ext.text = FALSE, 
                               ind = FALSE, cat.dist = 0.01)
      grid.draw(h1)
      grid.text("Down Regulated", y = 1)
      upViewport()
      pushViewport(vp2)
      h2 <- draw.pairwise.venn(length(1:indlist1.lr), length(1:indlist2.lr), 
                               length(genelist.lr), category = c(labels[1], 
                                                                 labels[2]), scaled = TRUE, lwd = c(0, 0), fill = c("cornflowerblue", 
                                                                                                                    "darkorchid1"), cex = 1, cat.cex = 1.2, cat.pos = c(0, 
                                                                                                                                                                        0), ext.text = FALSE, main = "Negative", ind = FALSE, 
                               cat.dist = 0.01)
      grid.draw(h2)
      grid.text("Up Regulated", y = 1)
      dev.off()
    })
    if (length(h2) == 0L) 
      message("Unable to output JPG plots.")
  }
  result$hypermat <- hypermat
  result$hypermat.counts <- .hypermat$counts
  result$hypermat.signs <- .hypermat$signs
  return(result)
}


#From this point, the script is written by Abbey, original can be found at:
#/stor/work/FRI-BigDataBio/rnaseq_visualization/research/RRHO

spec = matrix(c(
  'listA', 'a', 2, "character",
  'listB', 'b', 2, "character",
  'xlab', 'x', 1, "character",
  'ylab', 'y', 1, "character",
  'alternative', 'l', 2, 'double',
  'outputDirectory', 'o', 2, "character"
), byrow=TRUE, ncol=4)
opt = getopt(spec)

#read in listA
listA <- read.table(opt$listA, sep=',', header = T)
#get rid of na values and pull out padj column
listA <- na.omit(listA)
#padj is 1,7
listA_input <- listA[,c(1,7)]
#transform padj using -log10 * sign(log2fc)
listA_input$padj <- -1*log10(listA_input$padj)*sign(listA$log2FoldChange)

#read in listB
listB <- read.table(opt$listB, sep=',', header = T)
#get rid of na values and pull out padj column
listB <- na.omit(listB)
#padj is 1,7
#l2fc is 1,3
listB_input <- listB[,c(1,7)]
#transform padj using -log10 * sign(log2fc)
listB_input$padj <- -1*log10(listB_input$padj)*sign(listB$log2FoldChange)

#if listA and listB have different numbers of genes, we need to look at the intersection
intersection <- intersect(listA_input$X, listB_input$X)
#print(intersection)
listA_input <- listA_input[listA_input$X %in% intersection,]
listB_input <- listB_input[listB_input$X %in% intersection,]


#run with given alternative, default to enrichment 
if (is.null(opt$alternative)){ alt='enrichment'
}else if(opt$alternative ==  1){alt='enrichment'
}else if (opt$alternative == 2){alt='two.sided'}

#output to given output directory
if(is.null(opt$outputDirectory)){out = getwd()
}else{out=opt$outputDirectory}

#RRHO plots
RRHO.example <-  RRHO(listA_input, listB_input, 
                      BY=TRUE, alternative=alt, plots=T, outputdir = out, labels=c(opt$xlab,opt$ylab))

