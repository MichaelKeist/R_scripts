#def.par <- par(no.readonly = TRUE) # save default, for resetting...
library(jpeg)
library(graphics)
library(pheatmap)
install.packages("geotopbricks")
jet.colors <- colorRampPalette(c("#00007F", "blue", 
                                 "#007FFF", "cyan", "#7FFF7F", "yellow", "#FF7F00", 
                                 "red", "#7F0000"))
color.bar <- function(lut, min, max = -min, nticks = 11, 
                      ticks = seq(min, max, len = nticks), title = "") {
  scale <- (length(lut) - 1)/(max - min)
  # print("min is: ", min)
  # print("max is: ", max)
  plot(c(0, 10), c(min, max), type = "n", bty = "n", 
       xaxt = "n", xlab = "", yaxt = "n", ylab = "")
  mtext(title, 2, 3, cex = 1.5)
  axis(2, round(ticks, 0), las = 1, cex.lab = 1)
  for (i in 1:(length(lut) - 1)) {
    y <- (i - 1)/scale + min
    rect(0, y, 10, y + 1/scale, col = lut[i], border = NA)
  }
}
# plot_jpeg = function(path, add=FALSE)
# {
#   require('jpeg')
#   jpg = readJPEG(path, native=T) # read the file
#   res = dim(jpg)[2:1] # get the resolution, [x, y]
#   if (!add) # initialize an empty plot area if add==FALSE
#     plot(1,1,xlim=c(1,res[1]),ylim=c(1,res[2]),asp=1,type='n',xaxs='i',yaxs='i',xaxt='n',yaxt='n',xlab='',ylab='',bty='n')
#   rasterImage(jpg,1,1,res[1],res[2])
# }

## divide the device into two rows and two columns
## allocate figure 1 all of row 1
## allocate figure 2 the intersection of column 2 and row 2
#nf <- layout(matrix(c(1,1,0,2), 2, 2, byrow = TRUE), widths = c(lcm(7), lcm(7)), heights = c(lcm(7), lcm(7)))
## show the regions that have been allocated to each plot
files <- list.files(path="/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/visualizations/RRHO/formatted_maps", pattern="*.jpg", full.names=FALSE, recursive=FALSE)
files_long <- list.files(path="/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/visualizations/RRHO/formatted_maps", pattern="*.jpg", full.names=TRUE, recursive=FALSE)

category_vec <- c("BLA", "CEA", "BNST", "PFC", "VTA", "NAC")
# layout(matrix(c(0,0,0,0,0,1,
#                 0,0,0,0,2,3,
#                 0,0,0,4,5,6,
#                 0,0,7,8,9,10,
#                 0,11,12,13,14,15,
#                 16,17,18,19,20,21), 6, 6, byrow = TRUE), respect = FALSE) 
#layout.show()
jpeg(filename = "/stor/home/mk37825/did2_padj_tileset_new.jpg", 
      width = 40, height = 40, units = "in", quality = 100, 
      res = 150)
nf <- layout(matrix(c(1,0,0,0,0,
                      2,6,0,0,0,
                      3,7,10,0,0,
                      4,8,11,13,0,
                      5,9,12,14,15), 5, 5, byrow = TRUE))
                #widths = c(lcm(20),lcm(20),lcm(20),lcm(20),lcm(20),lcm(20)), heights = c(lcm(20),lcm(20),lcm(20),lcm(20),lcm(20),lcm(20)))
layout.show(nf)
library(jpeg)
par(mar = c(10,10,1,1))
par(omi = c(1,1,1,1))
i=1
while(i <= length(files_long)){
  x_label <- strsplit(files[i], "_")[[1]][2]
  y_label <- strsplit(strsplit(files[i], "_")[[1]][5],"\\.")[[1]][1]
  path=files_long[i]
  jpg = readJPEG(path, native=T) # read the file
  res = dim(jpg)[2:1] # get the resolution, [x, y]
  if(i %in% 1:4){
    plot(1,1,xlim=c(1,res[1]),ylim=c(1,res[2]),asp=1,type='n',xaxs='i',yaxs='i',xaxt='n',yaxt='n',xlab='',ylab=y_label,bty='n', cex.lab = 5)
  }else if(i %in% c(9,12,14,15)){
    plot(1,1,xlim=c(1,res[1]),ylim=c(1,res[2]),asp=1,type='n',xaxs='i',yaxs='i',xaxt='n',yaxt='n',xlab=x_label,ylab='',bty='n', cex.lab = 5)
  }else if(i == 5){
    plot(1,1,xlim=c(1,res[1]),ylim=c(1,res[2]),asp=1,type='n',xaxs='i',yaxs='i',xaxt='n',yaxt='n',xlab=x_label,ylab=y_label,bty='n', cex.lab = 5)
  }else{
    plot(1,1,xlim=c(1,res[1]),ylim=c(1,res[2]),asp=1,type='n',xaxs='i',yaxs='i',xaxt='n',yaxt='n',xlab='',ylab='',bty='n')
  }
  rasterImage(jpg,1,1,res[1],res[2])
  i = i + 1
}
dev.off()
#dev.new(width=1.5,height=5, unit = "px", noRStudioGD = TRUE)
jpeg(filename = "/stor/home/mk37825/did1_padj_tileset_new_images/scale.jpg", 
     width = 3, height = 9, units = "in", quality = 100, 
     res = 150)
par(mar = c(1,4.5,1,1))
color.bar(jet.colors(100), min = 0, max = 1023, nticks = 9, title = "-log(P-value)")
dev.off()
## divide device into two rows and two columns
## allocate figure 1 and figure 2 as above
## respect relations between widths and heights
