#!/bin/bash
for FILE in /stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/visualizations/RRHO/maps/*
do
	for TARGET in $FILE/*
	do
		PAT="^RRHOMap."
		SIMPLE_NAME=${TARGET##*/}
		if [[ $SIMPLE_NAME =~ $PAT ]] 
		then
			echo $SIMPLE_NAME 
			cp $TARGET /stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/visualizations/RRHO/formatted_maps/$SIMPLE_NAME
		fi
	done
done
