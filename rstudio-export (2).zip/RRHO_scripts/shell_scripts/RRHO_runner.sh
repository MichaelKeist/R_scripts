#!/bin/bash

#this script makes a commands file to run RRHOs on all possible pairwise combinations without repeats.
#this script considers an RRHO between x,y to be equal to RRHO between y,x, and so will only include one of those for any pair.
#for now, only looking at comparisons between same mouselines, so no comparisons between did1 and did2

#INPUT_DIRECTORY is loc of DESeq csv outputs
#R_SCRIPT is loc of RRHO script
#COMMAND_LOC is loc of the new command file
INPUT_DIRECTORY=$'/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value'
R_SCRIPT=$'/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/scripts/RRHO_scripts/RRHO_label_aligner.R'
COMMAND_LOC=$'/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/scripts/RRHO_scripts'

#RRHO_L is an input to the RRHO rscript, can be either enrichment (1) or two sided (2)
#RRHO_O_PREFIX is an input to the RRHO rscript, marking the output directory prefix
RRHO_L=1
RRHO_O_PREFIX=$"/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/visualizations/RRHO/"

#for comparing did1 groups, set LINE=$"did1", for did2 groups, LINE=$"did2"
#if you change the line, you may want to change the name of the output file on line 56!
LINE=$"did2"

#Initializing some important variables
KNOWN_PAIRS=()
i=1

#looping through all files of a given mouse line in input directory
for FILE1 in $INPUT_DIRECTORY/$LINE*
do
	NAME1=${FILE1##*/}
	for FILE2 in $INPUT_DIRECTORY/$LINE*	
	do
	    NAME2=${FILE2##*/}
	    #comparing the names of file1 and file2, can only run RRHO if different
	    if [[ "$NAME1" != "$NAME2" ]]
	    then
	    #check if these two groups are already being compared
	      if [[ ! ((" ${KNOWN_PAIRS[*]} " =~ " $NAME1,$NAME2 ") || (" ${KNOWN_PAIRS[*]} " =~ " $NAME2,$NAME1 ")) ]]
	      then
	        #when a new combination of 2 groups is found, add to our list of pairs
	        KNOWN_PAIRS[i]="$NAME1,$NAME2"
	        ((i=i+1))
	      fi
	    fi
	done
done

#loop through our set of RRHO pairs to create our commands
for PAIR in ${KNOWN_PAIRS[*]}
do
  RRHO_A=${PAIR%,*}
  RRHO_B=${PAIR##*,}
  RRHO_X=${RRHO_A%_output*}
  RRHO_Y=${RRHO_B%_output*}
  RRHO_O="$RRHO_O_PREFIX$RRHO_X""_"$RRHO_Y
  echo -e "mkdir $RRHO_O\nRscript $R_SCRIPT -a $INPUT_DIRECTORY/$RRHO_A -b $INPUT_DIRECTORY/$RRHO_B -x $RRHO_X -y $RRHO_Y -l $RRHO_L -o $RRHO_O" >> $COMMAND_LOC/RRHO_commands_did2
done
