#This script is just me trying out some of the functions in the RRHO library
library("RRHO")
library("dplyr")
#devtools::install_github("collectivemedia/tictoc")
library("tictoc")
library("data.table")

###LOADING GENE LISTS
list1_loc <- "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value/did1_BLA_output.csv"
list2_loc <- "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value/did2_CEA_output.csv"

###MAKING RRHO INPUTS
frame_1 <- as.data.frame(fread(list1_loc))
frame_2 <- as.data.frame(fread(list2_loc))

#omit nas
frame_1 <- na.omit(frame_1)
frame_2 <- na.omit(frame_2)

#getting log10 of padj, and looking only at padj < .05
frame1_input <- frame_1 %>%
  mutate(rrho_in = -log10(padj))

frame1_de <- frame1_input #%>%
  #filter(padj < .05)

frame2_input <- frame_2 %>%
  mutate(rrho_in = -log10(padj))

frame2_de <- frame2_input #%>%
  #filter(padj < .05)

###FOR GETTING DE GENES:
#this bit of code makes sure we look at every gene that had a padj < .05,
#making sure that no gene is listed twice. There was probably a better to go about this.
#There might be problems if there's a de gene that wasnt even measured for one of the groups, but that hasnt happened yet.
intersection <- intersect(frame1_de$V1, frame2_de$V1)

#target_genes <- c(frame1_de$V1[-which(frame1_de$V1 %in% intersection)], frame2_de$V1)
target_genes <- intersection

frame1_input <- frame1_input[which(frame1_input$V1 %in% target_genes),]
frame2_input <- frame2_input[which(frame2_input$V1 %in% target_genes),]

#this next bit gets the sign of the l2fc, to multiply with the log10padj
frame1_signs <- sign(frame_1$log2FoldChange)[which(frame_1$V1 %in% target_genes)]
frame2_signs <- sign(frame_2$log2FoldChange)[which(frame_2$V1 %in% target_genes)]

frame1_signs <- frame1_input$rrho_in * frame1_signs
frame2_signs <- frame2_input$rrho_in * frame2_signs

#subsetting our input frames so they work with the RRHO function
frame1_input <- frame1_input[,c("V1", "rrho_in")]
frame2_input <- frame2_input[,c("V1", "rrho_in")]

frame1_input$rrho_in <- frame1_signs
frame2_input$rrho_in <- frame2_signs

#This chunk of code seems irrelevant given what we already did
#But I'll keep it around for now just in case
#frame1_sign <- sign(frame1_input$log2FoldChange)
#frame2_sign <- sign(frame2_input$log2FoldChange)
#frame1_input$padj <- frame1_input$padj * frame1_sign
#frame2_input$padh <- frame2_input$padj * frame2_sign
#frame1_input <- frame1_input[,c("V1", "padj")]
#frame2_input <- frame2_input[,c("V1", "padj")]
###RUNNING RRHO
#the tic and toc bit measures how long the RRHO takes, because sometimes it takes a good while
tic("begin")
print("beginning RRHO")
RRHO_bla <- RRHO(frame1_input, frame2_input, BY=TRUE, alternative = "enrichment",
      plots = TRUE, outputdir = "~/did1_bla_cea_mk", labels = c("did1_bla", "did1_cea"))
print("RRHO finished")
toc()

pvalRRHO(RRHO_bla, replications = 50)

lattice::levelplot(RRHO_bla$hypermat.counts)

