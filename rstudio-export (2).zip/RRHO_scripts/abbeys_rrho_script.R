library('RRHO')
library('getopt')

spec = matrix(c(
  'listA', 'a', 2, "character",
  'listB', 'b', 2, "character",
  'xlab', 'x', 1, "character",
  'ylab', 'y', 1, "character",
  'alternative', 'l', 2, 'double',
  'outputDirectory', 'o', 2, "character"
), byrow=TRUE, ncol=4)
opt = getopt(spec)

#read in listA
listA <- read.table(opt$listA, sep=',', header = T)
#get rid of na values and pull out padj column
listA <- na.omit(listA)
#7 is padj, 3 is l2fc
listA_input <- listA[,c(1,3)]
#transform padj using -log10 * sign(log2fc)
#listA_input$padj <- -1*log10(listA_input$padj)*sign(listA$log2FoldChange)

#read in listB
listB <- read.table(opt$listB, sep=',', header = T)
#get rid of na values and pull out padj column
listB <- na.omit(listB)
listB_input <- listB[,c(1,3)]
#transform padj using -log10 * sign(log2fc)
#listB_input$padj <- -1*log10(listB_input$padj)*sign(listB$log2FoldChange)

#if listA and listB have different numbers of genes, we need to look at the intersection
intersection <- intersect(listA_input$X, listB_input$X)
#print(intersection)
listA_input <- listA_input[listA_input$X %in% intersection,]
listB_input <- listB_input[listB_input$X %in% intersection,]


#run with given alternative, default to enrichment 
if (is.null(opt$alternative)){ alt='enrichment'
}else if(opt$alternative ==  1){alt='enrichment'
}else if (opt$alternative == 2){alt='two.sided'}

#output to given output directory
if(is.null(opt$outputDirectory)){out = getwd()
}else{out=opt$outputDirectory}

#RRHO plots
RRHO.example <-  RRHO(listA_input, listB_input, 
                      BY=TRUE, alternative=alt, plots=T, outputdir = out, labels=c(opt$xlab,opt$ylab))

cat('RRHO complete for', opt$xlab, 'vs', opt$ylab)