#this file takes in the path to expRess result files, and expects them to have extension .xprs
files <- list.files(path = "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/htseq_counts", pattern = "*.txt", full.names = FALSE)
setwd("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/htseq_counts")
mydesign <- as.data.frame(fread("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/annot_table"))







columnlist <- list()
countsframe <- fread(files[1])[,1]
for(x in files){
  newtable <- fread(x)
  countsframe <- cbind(countsframe, newtable[,2])
}
countsframe <- as.data.frame(countsframe)
row.names(countsframe) <- countsframe$V1
countsframe <- countsframe[-c(1)]

samplenames <- as.data.frame(fread("../samplenames"))
colnames(countsframe) <- samplenames$`Sample	mouse_line`

deletedareas <- countsframe[c(56355:56359),]
countsframe <- countsframe[-c(56355:56359),]

countsframe$gene <- rownames(countsframe)
countsframe$gene <- NULL

erccframe <- countsframe[56263:56354,]

countsframe <- countsframe[-c(56263:56354),]

mix2counts <- select(erccframe, DID1FBL114_S1, DID1MBL184_S6, DID2MBL264_S12, DID2FBL244_S17, HSNpMBL64_S22, HSNpFBL44_S27, DID1FBL145_S37, DID1MBL205_S40, DID2FBL225_S43, DID2MBL285_S46, HSNpFBL35_S55, HSNpMBL95_S58)

mix2counts$average <- apply(mix2counts, FUN = mean, MARGIN = 1)
mix2counts$log2avg <- log2(mix2counts$average)

write.csv(mix2counts, "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/ERCC/mix2counts")

mix1counts <- select(erccframe, DID1FBL124_S3, DID1MBL204_S10, DID2MBL274_S14, DID2FBL254_S19, HSNpMBL74_S24, HSNpMBL104_S30, DID1MBL165_S32, DID2MBL305_S50, HSNpFBL15_S51, HSNpMBL75_S54)
mix1counts$average <- apply(mix1counts, FUN = mean, MARGIN = 1)
mix1counts$log2avg <- log2(mix1counts$average)

write.csv(mix1counts, "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/ERCC/mix1counts.csv")
