library(DESeq2)
setwd("/stor/scratch/WCAAR/gayatri_scratch/Angela_Project_JA20218/Brain_regions/BNST/Star_files/Htseq_Bnst")
directory<- "/stor/scratch/WCAAR/gayatri_scratch/Angela_Project_JA20218/Brain_regions/BNST/Star_files/Htseq_Bnst"
sampleinfo<-read.csv("Bnst_sampledata_deseq2.csv",header=TRUE)
SampleName <- sampleinfo$Sample
sampleGenotype = sampleinfo$Genotype
sampleSex <-sampleinfo$Sex
sampleFiles <- grep(".count.sorted.txt",list.files(directory),value=TRUE)
sampleTable <- data.frame(sampleName = SampleName,fileName = sampleFiles,Genotype = sampleGenotype,Sex=sampleSex)
sampleTable ##make sure all the samples and files are in correct order
ddsHTSeq <- DESeqDataSetFromHTSeqCount(sampleTable = sampleTable,directory = directory,design= ~ Genotype)
datExpr0<- assay(ddsHTSeq)	
dim(ddsHTSeq)
write.csv(datExpr0,file='Htseq_count_Bnst_samples.csv')