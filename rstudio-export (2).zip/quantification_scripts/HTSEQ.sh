#!/bin/bash
cd /stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/mapping
for i in `ls -1 *.bam | sed 's/.bam//'`;
do
  echo "htseq-count -m intersection-nonempty -s yes -f bam -r pos -t gene /stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/mapping/$i.bam /stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/GRCm38genome/ERCC.gencode.vM25.chr_patch_hapl_scaff.annotation.gtf > /stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/$i.count.sorted.txt" >> htseqcommands ;
done