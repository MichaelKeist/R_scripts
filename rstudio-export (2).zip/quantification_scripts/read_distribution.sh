#!/bin/bash
for FILE in /stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/mapping/bamfiles/*.bam
do
  NAME=$(echo $FILE | cut -d / -f 9 | cut -d . -f 1 | cut -c6-)
  /stor/home/mk37825/.local/bin/read_distribution.py -i $FILE -r /stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/GRCm38genome/ERCC.gencode.vM25.chr_patch_hapl_scaff.annotation.bed > /stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/mapping/bamfiles/$NAME.read_distribution.txt
done