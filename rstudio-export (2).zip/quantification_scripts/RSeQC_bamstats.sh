#!/bin/bash
cd /stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/mapping/bamfiles
for FILE in *
do
  NAME=$(echo "$FILE" | cut -d / -f 9 | cut -d . -f 1 | cut -c 6-)
  bam_stat.py -i $FILE > $FILE.stats
done