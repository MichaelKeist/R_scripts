setwd("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/currentlyuseful")
frame <- as.data.frame(fread("did1_BLA.csv"))
filter_frame <- frame %>%
  filter(padj < .05)
upreg <- filter_frame %>%
  filter(log2FoldChange > 0)
downreg <- filter_frame %>%
  filter(log2FoldChange < 0)

upgenes <- upreg$V1
downgenes <- downreg$V1

write_lines(upgenes, "~/CDS/upreg")
write_lines(downgenes, "~/CDS/downreg")

