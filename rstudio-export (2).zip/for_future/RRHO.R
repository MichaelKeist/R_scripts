#This script is just me trying out some of the functions in the RRHO library
library("RRHO")
library("dplyr")
devtools::install_github("collectivemedia/tictoc")
library("tictoc")

###LOADING GENE LISTS
list1_loc <- "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value/did1_CEA_output.csv"
list2_loc <- "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value/did2_CEA_output.csv"

###MAKING RRHO INPUTS
frame_1 <- as.data.frame(fread(list1_loc))
frame_2 <- as.data.frame(fread(list2_loc))

frame1_input <- frame_1 %>%
  mutate(rrho_in = -log10(padj))

frame1_de <- frame1_input %>%
  filter(padj < .05)

frame2_input <- frame_2 %>%
  mutate(rrho_in = -log10(padj))

frame2_de <- frame2_input %>%
  filter(padj < .05)

###FOR GETTING DE GENES:
intersection <- intersect(frame1_de$V1, frame2_de$V1)
target_genes <- c(frame1_de$V1[-which(frame1_de$V1 %in% intersection)], frame2_de$V1)

frame1_input <- frame1_input[which(frame1_input$V1 %in% target_genes),]
frame2_input <- frame2_input[which(frame2_input$V1 %in% target_genes),]

frame1_input <- frame1_input[,c("V1", "rrho_in")]
frame2_input <- frame2_input[,c("V1", "rrho_in")]


###RUNNING RRHO
tic("begin")
print("beginning RRHO")
RRHO_bla <- RRHO(frame1_input, frame2_input, BY=TRUE, alternative = "enrichment",
      plots = TRUE, outputdir = "~/CEA_RRHO", labels = c("did1_cea", "did2_cea"))
print("RRHO finished")
toc()

pvalRRHO(RRHO_bla, replications = 50)

lattice::levelplot(RRHO_bla$hypermat.counts)
