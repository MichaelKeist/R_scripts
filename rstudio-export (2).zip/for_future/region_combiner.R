#This script is supposed to combine counts from several brain regions, and make a unified annotation matrix
library(ggfortify)

#RETRIEVING DATA
bnst_counts <- as.data.frame(fread("/stor/work/WCAAR/scratch/eke_scratch/Angela/DESeq_by_tissue/BNST/2020-11-25-normalizedcounts.csv"))
nac_counts <- as.data.frame(fread("/stor/work/WCAAR/scratch/eke_scratch/Angela/DESeq_by_tissue/NAC/2020-12-01-normalizedcounts-NAC.csv"))
pfc_counts <- as.data.frame(fread("/stor/work/WCAAR/scratch/eke_scratch/Angela/DESeq_by_tissue/PFC/2020-12-01-normalizedcounts-PFC.csv"))
bla_and_cea_counts <- as.data.frame(fread("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/all_ddsnormalized.csv"))

#To make this work, I think we have to only look at genes that were counted in every region
bnst_genes <- bnst_counts$V1
nac_genes <- nac_counts$V1
pfc_genes <- pfc_counts$V1
bla_and_cea_genes <- bla_and_cea_counts$V1

common_genes <- intersect(bnst_genes, nac_genes)
common_genes <- intersect(common_genes, pfc_genes)
common_genes <- intersect(common_genes, bla_and_cea_genes)

bnst_trim <- bnst_counts[which(bnst_counts$V1 %in% common_genes),]
rownames(bnst_trim) <- bnst_trim$V1
nac_trim <- nac_counts[which(nac_counts$V1 %in% common_genes),]
rownames(nac_trim) <- nac_trim$V1
pfc_trim <- pfc_counts[which(pfc_counts$V1 %in% common_genes),]
rownames(pfc_trim) <- pfc_trim$V1
bla_and_cea_trim <- bla_and_cea_counts[which(bla_and_cea_counts$V1 %in% common_genes),]
rownames(bla_and_cea_trim) <- bla_and_cea_trim$V1


common_frame <- cbind(bnst_trim, nac_trim)
common_frame <- cbind(common_frame, pfc_trim)
common_frame <- cbind(common_frame, bla_and_cea_trim)

common_frame <- common_frame[,!grepl("V1", colnames(common_frame))]
common_frame <- common_frame[,!grepl("Row.", colnames(common_frame))]


#MAKING ANNOT TABLE
annot <- data.frame(sample=c(colnames(bnst_trim)[-1],colnames(nac_trim)[-1],colnames(pfc_trim)[-1],colnames(bla_and_cea_trim)[-1]))

bla_and_cea_region <- c()
for(i in 2:length(colnames(bla_and_cea_trim))){
  if(grepl("4_S", colnames(bla_and_cea_trim)[i])){
      bla_and_cea_region <- c(bla_and_cea_region, "BLA")
  }else{
    bla_and_cea_region <- c(bla_and_cea_region, "CEA")
  }
}
region_vec <- c(rep.int("BNST", 119), rep.int("NAC", 119), rep.int("PFC", 118), bla_and_cea_region)

annot$region <- region_vec 

sex_vec <- c()
for(i in annot$sample){
  if(grepl("M", substr(i,5,5))){
    sex_vec <- c(sex_vec, "Male")
  }else{
    sex_vec <- c(sex_vec, "Female")
  }
}  

annot$sex <- sex_vec

rownames(annot) <- annot$sample
annot$sample <- NULL

line_vec <- c(substr(rownames(annot), 1, 4))
annot$line <- line_vec

#SAVING RELEVANT FRAMES
write.csv(annot, "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/all_brain_regions_tables/annot.csv")
write.csv(common_frame, "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/all_brain_regions_tables/counts.csv")

#PLOTTING
pca_in <- princomp(common_frame)
autoplot(pca_in, data=annot, colour="region")





