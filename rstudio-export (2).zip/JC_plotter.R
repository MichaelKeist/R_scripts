#This script reads in enrichR results and DESeq2 outputs to give overlaps
#of pathways and DEGs across brain regions
library(ComplexHeatmap)
library(cowplot)
library(ggplotify)

#https://stackoverflow.com/questions/26314701/r-reducing-colour-saturation-of-a-colour-palette
desat <- function(cols, sat=0.9) {
  X <- diag(c(1, sat, 1)) %*% rgb2hsv(col2rgb(cols))
  hsv(X[1,], X[2,], X[3,])
}
filler <- function(a,b,c,d,e,f,g){
  return(input_frame[a,b])
}


#load data
deseq_files <- list.files(path = "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value", full.names = TRUE)
sample_names <- list.files("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value")
enrichment_files <- list.files(path = "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/visualizations/enrichment",
                           pattern = "*_enriched", full.names = TRUE)
#initialize variables
deseq_list <- list()
deg_list <- list()
enrichment_results <- list()
pathway_list <- list()

#looping to get significant genes from each brain region/mouseline
for(i in 1:length(deseq_files)){
  new_element <- read.table(file = deseq_files[i], header = TRUE, sep = ",")
  new_element <- new_element[which(new_element$padj <= 0.20),]
  deseq_list[[i]] <- new_element
  sample_name <- strsplit(sample_names[i], "_")
  sample_name <- paste(sample_name[[1]][1], sample_name[[1]][2],sep = "_")
  names(deseq_list)[i] <- sample_name
}

#looping to get enrichment results
for(i in 1:length(enrichment_files)){
  input_data <- readRDS(enrichment_files[[i]])
  enrichment_results[[i]] <- input_data@result[which(input_data@result$pvalue <= 0.05),]
  names(enrichment_results)[i] <- paste(strsplit(strsplit(enrichment_files[i], "/")[[1]][9], "_")[[1]][1], strsplit(strsplit(enrichment_files[i], "/")[[1]][9], "_")[[1]][2], sep = "_")
}

#getting union of pathways from different mouseline from same region
count <- 1
while(count <= length(enrichment_results)/2){
  pathway_list[[count]] <- union(enrichment_results[[count]]$Description, enrichment_results[[count+6]]$Description)
  count <- count + 1
}
names(pathway_list) <- c("BLA", "BNST", "CEA", "NAC", "PFC", "VTA")

#getting union of genes from different mouseline from same region
count <- 1
while(count <= (length(deseq_list))/2){
  deg_list[[count]] <- union(deseq_list[[count]]$X, deseq_list[[count+6]]$X)
  count <- count + 1
}
names(deg_list) <- c("BLA", "BNST", "CEA", "NAC", "PFC", "VTA")

#preparing heatmap dataframe
input_frame <- data.frame(BLA=rep(0,length(deg_list)), BNST=rep(0,length(deg_list)),
                          CEA=rep(0,length(deg_list)), NAC=rep(0,length(deg_list)),
                          PFC=rep(0,length(deg_list)), VTA=rep(0,length(deg_list)))
rownames(input_frame) <- colnames(input_frame)

#looping through dataframe cells
i <- 1
j <- 1
while(i <= length(rownames(input_frame))){
  j <- 1
  while(j <= length(colnames(input_frame))){
    if(!(j > i)){
      input_frame[i,j] <- length(intersect(deg_list[[i]], deg_list[[j]]))/length(union(deg_list[[i]], deg_list[[j]]))
    }else{
      input_frame[i,j] <- length(intersect(pathway_list[[i]], pathway_list[[j]]))/length(union(pathway_list[[i]], pathway_list[[j]]))
    }
    j <- j + 1
  }
  i <- i + 1
}

pal <- c("#66cc66","#99cc66","#ffff99","#ff9966","#ff6666")
#pal <- brewer.pal(n = 11, name ="RdYlGn")
pal <- desat(pal)
jc_plot <- Heatmap(input_frame, col = colorRampPalette(rev(pal))(100),
        cluster_rows = FALSE, cluster_columns = FALSE, name = "Overlap",
        border = TRUE, rect_gp = gpar(col = "black", lwd = 1),
        show_heatmap_legend = T, width = ncol(input_frame)*unit(30, "mm"),
        height = nrow(input_frame)*unit(15, "mm"), row_names_centered = T,
        row_names_side = "left", column_names_centered = T, column_names_side = "top",
        column_names_rot = 0,
        cell_fun = function(j, i, x, y, width, height, fill) {
          grid.text(sprintf("%.2f", input_frame[i, j]), x, y, gp = gpar(fontsize = 10))
        }, row_names_gp = gpar(fontfamily = "serif", fontface = "bold"), column_names_gp = gpar(fontfamily = "serif", fontface = "bold"),
        column_title = "Overlaps of DEGs and Pathways\n", column_title_gp = gpar(fontfamily = "serif", fontface = "bold", fontsize = 20),
        )
jc_plot
#segments(0,100,200,200)
#dev.off()
#jc_plot <- as.ggplot(jc_plot)
#plot_grid(jc_plot, labels = "A")
#in this case, the fractional overlap will be defined as
#(#of overlapping genes)/(#number of unique genes in the two sets)
#in other words: intersect(x,y)/union(x,y)
