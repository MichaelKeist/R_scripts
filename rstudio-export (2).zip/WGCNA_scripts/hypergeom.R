##import stuff
library(readr)
library(dplyr)
library(biomaRt)

#ensemble
ensembl = useMart("ENSEMBL_MART_ENSEMBL", dataset="mmusculus_gene_ensembl", host="www.ensembl.org")


#function to read in list
list2genevec <- function(file) {
  #read in file
  df <- as.data.frame(read_lines(file))
  colnames(df)[1] <- 'ensemble_ID'
  #match gene names to ensemble names
  annot<-getBM(c("ensembl_gene_id_version","ensembl_gene_id", "mgi_symbol","description", "chromosome_name", "strand", "start_position", "end_position","gene_biotype"),values= df$ensemble_ID, mart=ensembl)
  matchedannot <- match(df$ensemble_ID,annot$ensembl_gene_id)
  print(matchedannot)
  #create df with gene names
  dfgenes <- data.frame(cbind(df, annot[matchedannot,3]))
  #retrieve vector of only gene names
  colnames(dfgenes)[2] <- 'gene'
  genevec <- as.vector(dfgenes$gene)
  print(genevec)
  return(genevec)
  
}

#get list from vector (make sure the files are cut)
redvec <- list2genevec('/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/gene_lists/redlist.txt')
blackvec <- list2genevec('/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/gene_lists/blacklist.txt')
greenvec <- list2genevec('/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/gene_lists/greenlist.txt')

write_lines(redvec, path = '../gene_lists/red_genevec')
write_lines(greenvec, path = '../gene_lists/green_genevec')
write_lines(blackvec, path = '../gene_lists/black_genevec')


#get DE Gene Vecs
did1genes <- read_lines('../DESeq/currentlyuseful/gene_lists/did1_genes_no_outlier')
did1vec <- as.vector(did1genes)
did2genes <- read_lines('../DESeq/currentlyuseful/gene_lists/did2_genes_no_outlier')
did2vec <- as.vector(did2genes)


#phyper func
phyperfunc <- function(DEvec, colorvec, totcount = 27514) {
  if (is.character(colorvec)) {
    colorvec <- eval(parse(text = colorvec))
  }
  overlap <- Reduce(intersect, list(DEvec, colorvec))
  phyper <- phyper(length(overlap), length(DEvec), totcount - length(DEvec), length(colorvec), lower.tail = F, log.p = F)
  output <- c(phyper, length(overlap))
  return(output)
}

#create phypertable

did1_phy <- c(phyperfunc(did1vec, 'blackvec')[1], phyperfunc(did1vec, 'greenvec')[1], phyperfunc(did1vec, 'redvec')[1])
did2_phy <- c(phyperfunc(did2vec, 'blackvec')[1], phyperfunc(did2vec, 'greenvec')[1], phyperfunc(did2vec, 'redvec')[1])

phyperdf <- data.frame(ModuleColor = c('black', 'green', 'red'), DID1_DE_PHyper = did1_phy, DID2_DE_PHyper = did2_phy)

