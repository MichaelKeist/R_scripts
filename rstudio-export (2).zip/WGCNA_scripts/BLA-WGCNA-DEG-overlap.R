
library(biomaRt)
library(dplyr)

#load BLA Data
load("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/BLA/RData/2021-07-23-BLA-only-SamplesAndTraits.RData")
load("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/BLA/RData/2021-07-23-BLA-only-Network_allSamples_signed_RLDfiltered.RData")
load("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/BLA/RData/2021-07-23-BLA-only-Network_allSamples_signed_nomerge_RLDfiltered.RData")
#set BLA Data
BLAmoduleColorstable <- table(moduleColors)
# get genes
BLA_genes_key <-  data.frame(colnames(datExpr), moduleColors)
#ask what should be background
bg <- c(colnames(datExpr))
# 
# #load CEA Data
# load("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/CEA/RData/2021-07-26-CEA-only-Network_allSamples_signed_nomerge_RLDfiltered.RData")
# load("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/CEA/RData/2021-07-26-CEA-only-Network_allSamples_signed_RLDfiltered.RData")
# #set CEA Data
# CEAmoduleColorstable <- table(moduleColors)
# # get genes
# CEA_genes_key <-  data.frame(colnames(datExpr), moduleColors)

#get list to gene vec
ensembl = useMart("ENSEMBL_MART_ENSEMBL", dataset="mmusculus_gene_ensembl", host="www.ensembl.org")

dot_remover <- function(input){
  return(strsplit(input,"\\.")[[1]][1])
}

#function to read in list
list2genevec <- function(file) {
  #read in file
  df <- as.data.frame(read_lines(file))
  colnames(df)[1] <- 'ensemble_ID'
  df$ensemble_ID <- as.vector(lapply(df$ensemble_ID, FUN = dot_remover))
  #match gene names to ensemble names
  annot<-getBM(c("ensembl_gene_id_version","ensembl_gene_id", "mgi_symbol","description", "chromosome_name", "strand", "start_position", "end_position","gene_biotype"),values= df$ensemble_ID, mart=ensembl)
  matchedannot <- match(df$ensemble_ID,annot$ensembl_gene_id)
  #create df with gene names
  dfgenes <- data.frame(cbind(df, annot[matchedannot,3]))
  #retrieve vector of only gene names
  colnames(dfgenes)[2] <- 'gene'
  genevec <- as.vector(dfgenes$gene)
  print(genevec)
  return(genevec)
}
# 
# #get DE Genes List
# did1BLAgenes <- as.list(read_lines('/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/gene_lists/did1_BLA_genes'))
# did2BLAgenes <- as.list(read_lines('/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/gene_lists/did2_BLA_genes'))
# did1CEAgenes <- as.list(read_lines('/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/gene_lists/did1_CEA_genes_no_outlier'))
# did2CEAgenes <- as.list(read_lines('/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/gene_lists/did2_CEA_genes_no_outlier'))

#get up/down DEG list

did1BLAgenes_up <- list2genevec('/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/gene_lists/upreg_downreg/upreg_did1_BLA')
did1BLAgenes_down <- list2genevec('/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/gene_lists/upreg_downreg/downreg_did1_BLA')
did2BLAgenes_up <- list2genevec('/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/gene_lists/upreg_downreg/upreg_did2_BLA')
did2BLAgenes_down <- list2genevec('/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/gene_lists/upreg_downreg/downreg_did2_BLA')

#convert
#did2BLAgenes <- as.list(read_lines('/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/gene_lists/did2_BLA_genes'))
#did1CEAgenes <- as.list(read_lines('/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/gene_lists/did1_CEA_genes_no_outlier'))
#did2CEAgenes <- as.list(read_lines('/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/gene_lists/did2_CEA_genes_no_outlier'))

# allBLAgenes <- intersect(did1BLAgenes, did2BLAgenes)

#module enrichment function
moduleEnrichment <- function(geneList, moduleAssignments, background) {
  #moduleAssignments - a dataframe, first column containing gene names, second with module assignments 
  #geneList - a character vector of gene names you want to compare with modules (i.e. differentially expressed genes)
  #background - a character vector of gene names that make up the common background for the two comparisons
  colors <- names(table(moduleAssignments[,2]))
  deg <- intersect(geneList, moduleAssignments[,1])
  b <- length(deg)
  c <- length(background)
  sig <- NULL; d <- NULL; a <- NULL; p <- NULL ; percent <- NULL; percentDEG <- NULL
  for (i in colors) { 
    module =  subset(moduleAssignments, moduleAssignments[,2]== i)[,1]
    d[i] <- length(intersect(bg, module)) 
    a[i] <- length(intersect(deg, module))  
    p[i] <- phyper(a[i]-1, b, (c - b), d[i], lower.tail=FALSE, log.p = FALSE)  
    percent[i] <- a[i]/d[i]*100 #calculates percent of the module occupied by DEG 
    percentDEG[i] <- a[i]/(length(deg))*100 #calculates percent of the DEG in that module 
    if (p[i] < 0.05 ){
      sig[i] <- p[i] }}
  df <- cbind(a,p,percent,percentDEG)
  colnames(df) <- c("OverlappingGenes", "p.value", "%Module_Containing_GeneList", "%GeneList_Contained_in_Module")
  output <- list("table" = df, "significant" = sig)
  return(output)
}
# enrich_HDID1BLA <- moduleEnrichment(did1BLAgenes, BLA_genes_key, bg)
# enrich_HDID2BLA <- moduleEnrichment(did2BLAgenes, BLA_genes_key, bg)
# enrich_HDID1CEA <- moduleEnrichment(did1CEAgenes, CEA_genes_key, bg)
# enrich_HDID2CEA <- moduleEnrichment(did2CEAgenes, CEA_genes_key, bg)
# 
# enrich_allBLA <- moduleEnrichment(allBLAgenes, BLA_genes_key, bg)

#for up & down
enrich_HDID1BLA_up <- moduleEnrichment(did1BLAgenes_up, BLA_genes_key, bg)
enrich_HDID1BLA_down <- moduleEnrichment(did1BLAgenes_down, BLA_genes_key, bg)
enrich_HDID2BLA_up <- moduleEnrichment(did2BLAgenes_up, BLA_genes_key, bg)
enrich_HDID2BLA_down <- moduleEnrichment(did2BLAgenes_down, BLA_genes_key, bg)

#get significant
enrich_HDID1BLA_up$significant
##pink, purple, red, turquoise
#5.466610e-03 4.069008e-25 7.390688e-20 1.279837e-13 
enrich_HDID2BLA_down$significant
#blue        brown          red       yellow 
#7.467246e-12 4.455059e-22 4.802589e-07 2.840821e-41 
enrich_HDID1BLA_down$significant
#black        brown  greenyellow       yellow 
#1.489121e-20 2.578069e-17 5.907897e-56 1.996848e-07
enrich_HDID2BLA_up$significant
# black        brown  greenyellow       yellow 
#1.489121e-20 2.578069e-17 5.907897e-56 1.996848e-07 


##enriched modules in individual networks
#load BLA HDID1
load("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/BLA/HSN_DID1/2021-07-23-BLA-DID1-Network_allSamples_signed_nomerge_RLDfiltered.RData")
load("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/BLA/HSN_DID1/2021-07-23-BLA-DID1-Network_allSamples_signed_RLDfiltered.RData")
load("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/BLA/HSN_DID1/2021-07-23-BLA-DID1-SamplesAndTraits.RData")
#create BLA_DID1_Genes_Key
BLA_DID1_genes_key <-  data.frame(colnames(datExpr), moduleColors)
bg1 <- colnames(datExpr)
#load BLA HDID2
load("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/BLA/HSN_DID2/2021-07-23-BLA-DID2-Network_allSamples_signed_nomerge_RLDfiltered.RData")
load("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/BLA/HSN_DID2/2021-07-23-BLA-DID2-Network_allSamples_signed_RLDfiltered.RData")
load("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/BLA/HSN_DID2/2021-07-23-BLA-DID2-SamplesAndTraits.RData")
#create BLA_DID2_Genes_Key
BLA_DID2_genes_key <-  data.frame(colnames(datExpr), moduleColors)
bg2 <- colnames(datExpr)
#get enrichment

#for up & down
enrich_HDID1BLA_up_ind <- moduleEnrichment(did1BLAgenes_up, BLA_DID1_genes_key, bg1)
enrich_HDID1BLA_down_ind <- moduleEnrichment(did1BLAgenes_down, BLA_DID1_genes_key, bg1)
enrich_HDID2BLA_up_ind <- moduleEnrichment(did2BLAgenes_up, BLA_DID2_genes_key, bg2)
enrich_HDID2BLA_down_ind <- moduleEnrichment(did2BLAgenes_down, BLA_DID2_genes_key, bg2)

#get significant
enrich_HDID1BLA_up_ind$significant
#black     turquoise 
#3.155457e-02 7.341883e-160  
enrich_HDID1BLA_down_ind$significant
#blue        brown       yellow 
#7.500735e-93 4.387637e-08 1.605972e-04 
enrich_HDID2BLA_up_ind$significant
# turquoise 
#2.882872e-233 
enrich_HDID2BLA_down_ind$significant
#blue         brown   greenyellow 
#7.166398e-109  2.549842e-17  3.750047e-03 





par(mfrow=c(2,2), mar=c(2, 5, 2, 2) , cex=.8)

#coloring
#DID1-BLA-up
setwd("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/BLA/up_down_analysis")
pdf(file = 'HDID1_up_BLA_overlap_modules.pdf', width = 7, height = 5)
barplot(enrich_HDID1BLA_up$table[,3], col = rownames(enrich_HDID1BLA_up$table), axisnames = F, ylim = c(0,100), ylab = "% Module Containing DEG", main = "Module enrichment for BLA HDID2 DE genes");
barplot(enrich_HDID1BLA_up$table[,4], col = rownames(enrich_HDID1BLA_up$table), axisnames = F, ylim = c(0,100), ylab = "% DEG Contained in Module", main = "Module distribution of BLA HDID2 DE genes")
dev.off()
#DID1-BLA-down
pdf(file = 'HDID1_down_BLA_overlap_modules.pdf', width = 7, height = 5)
barplot(enrich_HDID1BLA_down$table[,3], col = rownames(enrich_HDID1BLA_down$table), axisnames = F, ylim = c(0,100), ylab = "% Module Containing DEG", main = "Module enrichment for BLA HDID2 DE genes");
barplot(enrich_HDID1BLA_down$table[,4], col = rownames(enrich_HDID1BLA_down$table), axisnames = F, ylim = c(0,100), ylab = "% DEG Contained in Module", main = "Module distribution of BLA HDID2 DE genes")
dev.off()
#DID2-BLA-up
pdf(file = 'HDID2_up_BLA_overlap_modules.pdf', width = 7, height = 5)
barplot(enrich_HDID2BLA_up$table[,3], col = rownames(enrich_HDID2BLA_up$table), axisnames = F, ylim = c(0,100), ylab = "% Module Containing DEG", main = "Module enrichment for BLA HDID2 DE genes");
barplot(enrich_HDID2BLA_up$table[,4], col = rownames(enrich_HDID2BLA_up$table), axisnames = F, ylim = c(0,100), ylab = "% DEG Contained in Module", main = "Module distribution of BLA HDID2 DE genes")
dev.off()
#DID2-BLA-down
pdf(file = 'HDID2_down_BLA_overlap_modules.pdf', width = 7, height = 5)
barplot(enrich_HDID2BLA_down$table[,3], col = rownames(enrich_HDID2BLA_down$table), axisnames = F, ylim = c(0,100), ylab = "% Module Containing DEG", main = "Module enrichment for BLA HDID2 DE genes");
barplot(enrich_HDID2BLA_down$table[,4], col = rownames(enrich_HDID2BLA_down$table), axisnames = F, ylim = c(0,100), ylab = "% DEG Contained in Module", main = "Module distribution of BLA HDID2 DE genes")
dev.off()


#significant modules in BLA to files (blue, brown, red, turquoise)
#setwd('/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/gene_lists/BLA')
color_filter <- BLA_genes_key %>% filter(moduleColors == 'purple')
color_vec <- as.vector(color_filter$colnames.datExpr.)
#write_lines(color_vec, path = 'purple_gene_list.txt')

#do the same for CEA
#setwd('/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/DEG_overlap')
enrich_HDID1CEA$significant
enrich_HDID2CEA$significant
#pdf(file = 'HDID2_CEA_overlap_modules.pdf', width = 7, height = 5)
barplot(enrich_HDID2CEA$table[,3], col = rownames(enrich_HDID2CEA$table), axisnames = F, ylim = c(0,100), ylab = "% Module Containing DEG", main = "Module enrichment for CEA HDID2 DE genes");
barplot(enrich_HDID2CEA$table[,4], col = rownames(enrich_HDID2CEA$table), axisnames = F, ylim = c(0,100), ylab = "% DEG Contained in Module", main = "Module distribution of CEA HDID2 DE genes")
#dev.off()

#significant modules in CEA to files (blue, purple, yellow red, turquoise)
#setwd('/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/gene_lists/CEA')
color_filter <- CEA_genes_key %>% filter(moduleColors == 'turquoise')
color_vec <- as.vector(color_filter$colnames.datExpr.)
#write_lines(color_vec, path = 'turq_gene_list.txt')

#look for my overlap test
blue_filter <- BLA_genes_key %>% filter(moduleColors == 'blue')
turq_filter <- CEA_genes_key %>% filter(moduleColors == 'turquoise')
intersection <- intersect(as.vector(blue_filter$colnames.datExpr.), as.vector(turq_filter$colnames.datExpr.))

