library(WGCNA)




#load BLA Consensus
load("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/BLA/RData/2021-07-23-BLA-only-Network_allSamples_signed_nomerge_RLDfiltered.RData")
load("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/BLA/RData/2021-07-23-BLA-only-Network_allSamples_signed_RLDfiltered.RData")
BLAconsMEs <- MEs
BLAconsTree <- geneTree
BLAmoduleLabels <- moduleLabels
BLAmoduleColors <- moduleColors

#load BLA HDID1

load("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/BLA/HSN_DID1/2021-07-23-BLA-DID1-Network_allSamples_signed_nomerge_RLDfiltered.RData")
load("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/BLA/HSN_DID1/2021-07-23-BLA-DID1-Network_allSamples_signed_RLDfiltered.RData")
BLA_DID1_consMEs <- MEs
BLA_DID1_consTree <- geneTree
BLA_DID1_moduleLabels <- moduleLabels
BLA_DID1_moduleColors <- moduleColors

#load BLA HDID2
load("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/BLA/HSN_DID1/2021-07-23-BLA-DID1-Network_allSamples_signed_nomerge_RLDfiltered.RData")
load("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/BLA/HSN_DID1/2021-07-23-BLA-DID1-Network_allSamples_signed_RLDfiltered.RData")
BLA_DID1_consMEs <- MEs
BLA_DID1_consTree <- geneTree
BLA_DID1_moduleLabels <- moduleLabels
BLA_DID1_moduleColors <- moduleColors



#load CEA Consensus
load("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/CEA/RData/2021-07-26-CEA-only-Network_allSamples_signed_nomerge_RLDfiltered.RData")
load("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/CEA/RData/2021-07-26-CEA-only-Network_allSamples_signed_RLDfiltered.RData")
CEAconsMEs <- MEs
CEAconsTree <- geneTree
CEAmoduleLabels <- moduleLabels
CEAmoduleColors <- moduleColors

#load CEA HDID1
#load CEA


#consMEs1 <- rbind(MEs[1:10,], MEs[21:30,])
#plotDendroAndColors

#pdf('2021-07-26-BLA-vs-CEA-Consensus-Dendrogram.pdf')
#plotDendroAndColors(CEAconsTree, cbind(CEAmoduleColors,BLAmoduleColors), 
#                     c("CEA Consensus Module colors","BLA Consensus Module colors"), 
#                     main = "CEA vs. BLA Network Dendrogram", dendroLabels = FALSE, hang = 0.03, 
#                     addGuide = TRUE, guideHang = 0.05, marAll = c(2,8,2,2))
# dev.off()
# Isolate the module labels in the order they appear in ordered module eigengenes
BLAModuleLabels = substring(names(BLAconsMEs), 3)
BLA_DID1_moduleLabels = substring(names(BLA_DID1_consMEs), 3)
CEAModuleLabels = substring(names(CEAconsMEs), 3)
# Convert the numeric module labels to color labels
# HDID1Modules = labels2colors(as.numeric(HDID1ModuleLabels))
BLAconsModules <- BLAModuleLabels
BLA_DID1_consModules <- BLA_DID1_moduleLabels
CEAconsModules = CEAModuleLabels
# Numbers of female and consensus modules
nBLAMods = length(BLAconsModules)
nBLA_DID1Mods = length(BLA_DID1_consModules)
nCEAMods = length(CEAconsModules)
# Initialize tables of p-values and of the corresponding counts
pTable = matrix(0, nrow = nBLAMods, ncol = nCEAMods);
CountTbl = matrix(0, nrow = nBLAMods, ncol = nCEAMods);
# Execute all pairwaise comparisons
for (fmod in 1:nBLAMods)
  for (cmod in 1:nCEAMods)
  {
    BLAMembers = (BLAmoduleColors == BLAconsModules[fmod]);
    CEAMembers = (CEAmoduleColors == CEAconsModules[cmod]);
    pTable[fmod, cmod] = -log10(fisher.test(BLAMembers, CEAMembers, alternative = "greater")$p.value);
    CountTbl[fmod, cmod] = sum(BLAmoduleColors == BLAconsModules[fmod] & CEAmoduleColors ==
                                 CEAconsModules[cmod])
  }





# Truncate p values smaller than 10^{-50} to 10^{-50}
pTable[is.infinite(pTable)] = 1.3*max(pTable[is.finite(pTable)]);
pTable[pTable>50 ] = 50 ;
# Marginal counts (really module sizes)
BLAModTotals = apply(CountTbl, 1, sum)
CEAModTotals = apply(CountTbl, 2, sum)
# Actual plotting
sizeGrWindow(20,7 );
#pdf(file = "2021-07-27-ConsensusCEAVsBLAModules.pdf", wi = 10, he = 7);
par(mfrow=c(1,1))
par(cex = 0.75)
par(mar=c(11, 11, 2.7, 1)+0.3)
# Use function labeledHeatmap to produce the color-coded table with all the trimmings


labeledHeatmap(Matrix = pTable,
               xLabels = paste(" ", CEAconsModules),
               yLabels = paste(" ", BLAconsModules),
               colorLabels = T,
               xSymbols = paste("Consensus CEA ", CEAconsModules, ": ", CEAModTotals, sep=""),
               ySymbols = paste("Consensus BLA ", BLAconsModules, ": ", BLAModTotals, sep=""),
               textMatrix = signif(pTable, 1),
               colors = blueWhiteRed(100)[50:100],
               main = "Correspondence of CEA & BLA consensus modules", 
               setStdMargins = F,
               xColorOffset = 0, xColorWidth = .03, 
               yColorOffset = 0, yColorWidth = 0.03, cex.lab = 0.7)

dev.off()



#repeat process for BLA-HDID1

# Initialize tables of p-values and of the corresponding counts
pTable = matrix(0, nrow = nBLAMods, ncol = nBLA_DID1Mods);
CountTbl = matrix(0, nrow = nBLAMods, ncol = nBLA_DID1Mods);
# Execute all pairwaise comparisons
for (fmod in 1:nBLAMods)
  for (cmod in 1:nBLA_DID1Mods)
  {
    BLAMembers = (BLAmoduleColors == BLAconsModules[fmod]);
    BLA_DID1_Members = (BLA_DID1_moduleColors == BLA_DID1_consModules[cmod]);
    pTable[fmod, cmod] = -log10(fisher.test(BLAMembers, BLA_DID1_Members, alternative = "greater")$p.value);
    CountTbl[fmod, cmod] = sum(BLAmoduleColors == BLAconsModules[fmod] & BLA_DID1_moduleColors ==
                                 BLA_DID1_consModules[cmod])
  }





# Truncate p values smaller than 10^{-50} to 10^{-50}
pTable[is.infinite(pTable)] = 1.3*max(pTable[is.finite(pTable)]);
pTable[pTable>50 ] = 50 ;
# Marginal counts (really module sizes)
BLAModTotals = apply(CountTbl, 1, sum)
BLA_DID1_ModTotals = apply(CountTbl, 2, sum)
# Actual plotting
sizeGrWindow(20,7 );
pdf(file = "2021-09-27-ConsensusBLAVsBLA_HDID1_Modules.pdf", wi = 10, he = 7);
par(mfrow=c(1,1))
par(cex = 0.75)
par(mar=c(11, 11, 2.7, 1)+0.3)
# Use function labeledHeatmap to produce the color-coded table with all the trimmings


labeledHeatmap(Matrix = pTable,
               xLabels = paste(" ", BLA_DID1_consModules),
               yLabels = paste(" ", BLAconsModules),
               colorLabels = T,
               xSymbols = paste("BLA HDID1 ", BLA_DID1_consModules, ": ", BLA_DID1_ModTotals, sep=""),
               ySymbols = paste("Consensus BLA ", BLAconsModules, ": ", BLAModTotals, sep=""),
               textMatrix = CountTbl,
               colors = blueWhiteRed(100)[50:100],
               main = "Correspondence of BLA-HDID1 & BLA consensus modules", 
               setStdMargins = F,
               xColorOffset = 0, xColorWidth = .03, 
               yColorOffset = 0, yColorWidth = 0.03, cex.lab = 0.7)

dev.off()





