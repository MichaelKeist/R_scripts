
# Load WGCNA and flashClust libraries every time you open R
library(WGCNA)
library(flashClust)
library(dplyr)


# Uploading data into R and formatting it for WGCNA
# This creates an object called "datExpr" that contains the normalized counts file output from DESeq2
#datExpr = read.csv("../counts/rlog_all_deseqcounts.csv") - previous run; now on normalized

normalized.counts <- read.csv('/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/all_ddsnormalized.csv')
rownames(normalized.counts) <- normalized.counts$X
normalized.counts <- normalized.counts[,-1]
normalized.counts$HSNpMBL105_S60 <- NULL
log2Counts <- log2(normalized.counts)
log2Counts[log2Counts==-Inf] <- NA
no0_log2.normalized.counts <- na.omit(log2Counts)
# "head" the file to preview it
#head(datExpr) # You see that genes are listed in a column named "X" and samples are in columns
datExpr <- no0_log2.normalized.counts
# #filter for variance
# variance_vector = apply(datExpr[2:59], MARGIN = 1, FUN = var)
# datExpr$variance <- variance_vector
# #number of genes genes in top ten percent variance
# genes_to_filter <- nrow(datExpr) * 0.8
# #create subset with top ten varying genes
# datExpr <- datExpr %>%
#   arrange(desc(variance)) %>%
#   head(genes_to_filter)

# Manipulate file so it matches the format WGCNA needs
#row.names(datExpr) = datExpr$X
#datExpr$X = NULL
#datExpr$variance = NULL
datExpr = as.data.frame(t(datExpr)) # now samples are rows and genes are columns
dim(datExpr) # 48 samples and 1000 genes (you will have many more genes in reality)
head(datExpr)



# Run this to check if there are gene outliers
gsg = goodSamplesGenes(datExpr, verbose = 3)
gsg$allOK


#If the last statement returns TRUE, all genes have passed the cuts. If not, we remove the offending genes and samples from the data with the following:
#if (!gsg$allOK)
#   {if (sum(!gsg$goodGenes)>0)
#       printFlush(paste("Removing genes:", paste(names(datExpr)[!gsg$goodGenes], collapse= ", ")));
#       if (sum(!gsg$goodSamples)>0)
#           printFlush(paste("Removing samples:", paste(rownames(datExpr)[!gsg$goodSamples], collapse=", ")))
#       datExpr= datExpr[gsg$goodSamples, gsg$goodGenes]
#       }

setwd("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/goodnorm")
#Create an object called "datTraits" that contains your trait data
datTraits = read.csv("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/annot_table.csv", stringsAsFactors = F)
head(datTraits)
#form a data frame analogous to expression data that will hold the clinical traits.
rownames(datTraits) = datTraits$X
datTraits$X = NULL
datTraits$ERCC = NULL

# re-setting dataframe
DID1frame <- datTraits %>% filter(mouseline == 'DID1')
DID2frame <- datTraits %>% filter(mouseline == 'DID2')
HSNframe <- datTraits %>% filter(mouseline == 'HSNp')
femframe <- datTraits %>% filter(sex == 'F')
maleframe <- datTraits %>% filter(sex == 'M')
BLAframe <- datTraits %>% filter(brain_region == 'BLA')
CEAframe <- datTraits %>% filter(brain_region == 'CEA')

# add columns for diff lines
datTraits$HSN <- 0
datTraits$DID1 <- 0
datTraits$DID2 <- 0

#add columns for brain region
datTraits$BLA <- 0
datTraits$CEA <- 0

#for brain regions, set columns
datTraits[rownames(HSNframe), 4] <- 1
datTraits[rownames(DID1frame), 5] <- 1
datTraits[rownames(DID2frame), 6] <- 1

#for sex: F = 1, M = 2
datTraits[rownames(femframe), 2] <- 0
datTraits[rownames(maleframe), 2] <- 1


datTraits$mouseline <- NULL

#for brain_region: BLA = 1, CEA = 2
datTraits[rownames(BLAframe), 6] <- 1
datTraits[rownames(CEAframe), 7] <- 1

datTraits$brain_region <- NULL
datTraits$BLA <- NULL
datTraits$CEA <- NULL

### for BLA Consensus
BLATraits <- datTraits[rownames(BLAframe),]
BLAexpr <- datExpr[rownames(BLAframe),]

datTraits <- BLATraits
datExpr <- BLAexpr
table(rownames(datTraits)==rownames(datExpr)) #should return TRUE if datasets align correctly, otherwise your names are out of order
head(datTraits)

### for BLA HDID2 vs HSNpt
HDID2_HSN_samplelist <- intersect(c(rownames(DID2frame), rownames(HSNframe)), rownames(BLAframe))
DID2_BLATraits <- BLATraits[HDID2_HSN_samplelist, ]
DID2_BLAExpr <- datExpr[HDID2_HSN_samplelist, ]

datTraits <- DID2_BLATraits
datExpr <- DID2_BLAExpr
datTraits$DID1 <- NULL

table(rownames(datTraits)==rownames(datExpr)) #should return TRUE if datasets align correctly, otherwise your names are out of order
head(datTraits)
# You have finished uploading and formatting expression and trait data
# Expression data is in datExpr, corresponding traits are datTraits


save(datExpr, datTraits, file="2021-07-23-BLA-DID2-SamplesAndTraits.RData")
load("2021-07-23-BLA-DID2-SamplesAndTraits.RData")


# Choose a soft threshold power- USE A SUPERCOMPUTER IRL ------------------------------------

powers = c(c(1:10), seq(from =10, to=30, by=1)) #choosing a set of soft-thresholding powers
sft = pickSoftThreshold(datExpr, powerVector=powers, verbose =5, networkType="signed") #call network topology analysis function

sizeGrWindow(9,5)
par(mfrow= c(1,2))
cex1=0.9
pdf('2021-07-23-softpower-DID2-BLA.pdf')
plot(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2], xlab= "Soft Threshold (power)", ylab="Scale Free Topology Model Fit, signed R^2", type= "n", main= paste("Scale independence"))
text(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2], labels=powers, cex=cex1, col="red")
abline(h=0.90, col="red")
plot(sft$fitIndices[,1], sft$fitIndices[,5], xlab= "Soft Threshold (power)", ylab="Mean Connectivity", type="n", main = paste("Mean connectivity"))
text(sft$fitIndices[,1], sft$fitIndices[,5], labels=powers, cex=cex1, col="red")
dev.off()
#from this plot, we would choose a power of 18 becuase it's the lowest power for which the scale free topology index reaches 0.90

#for DID1; st = 7
#for DID2: st = 4
#for BLA: st = 5
#build a adjacency "correlation" matrix
enableWGCNAThreads()
softPower = 4
adjacency = adjacency(datExpr, power = softPower, type = "signed") #specify network type
head(adjacency)

# Construct Networks- USE A SUPERCOMPUTER IRL -----------------------------
#translate the adjacency into topological overlap matrix and calculate the corresponding dissimilarity:
TOM = TOMsimilarity(adjacency, TOMType="signed") # specify network type
dissTOM = 1-TOM

# Generate Modules --------------------------------------------------------


#first try- module size = 30
#second try- module size = 100
#third try- module size = 200
# Generate a clustered gene tree
geneTree = flashClust(as.dist(dissTOM), method="average")
plot(geneTree, xlab="", sub="", main= "Gene Clustering on TOM-based dissimilarity", labels= FALSE, hang=0.04)
#This sets the minimum number of genes to cluster into a module
minModuleSize = 100
dynamicMods = cutreeDynamic(dendro= geneTree, distM= dissTOM, deepSplit=2, pamRespectsDendro= FALSE, minClusterSize = minModuleSize)
dynamicColors= labels2colors(dynamicMods)
MEList= moduleEigengenes(datExpr, colors= dynamicColors,softPower = softPower)
MEs= MEList$eigengenes
MEDiss= 1-cor(MEs)
METree= flashClust(as.dist(MEDiss), method= "average")
save(dynamicMods, MEList, MEs, MEDiss, METree, file= "2021-07-23-BLA-DID2-Network_allSamples_signed_RLDfiltered.RData")


#plots tree showing how the eigengenes cluster together
#INCLUE THE NEXT LINE TO SAVE TO FILE
pdf(file="2021-07-23-BLA-DID2-clusterwithoutmodulecolorstrial.pdf")
plot(METree, main= "Clustering of module eigengenes", xlab= "", sub= "", cex = .5)
#set a threhold for merging modules. In this example we are not merging so MEDissThres=0.0
MEDissThres = 0.0
merge = mergeCloseModules(datExpr, dynamicColors, cutHeight= MEDissThres, verbose =3)
mergedColors = merge$colors
mergedMEs = merge$newMEs
#INCLUE THE NEXT LINE TO SAVE TO FILE
dev.off()

#plot dendrogram with module colors below it
#INCLUE THE NEXT LINE TO SAVE TO FILE
pdf(file="2021-07-23-BLA-DID2-cluster.pdf")
plotDendroAndColors(geneTree, cbind(dynamicColors, mergedColors), c("Dynamic Tree Cut", "Merged dynamic"), dendroLabels= FALSE, hang=0.03, addGuide= TRUE, guideHang=0.05)
moduleColors = mergedColors
colorOrder = c("grey", standardColors(50))
moduleLabels = match(moduleColors, colorOrder)-1
MEs = mergedMEs
#INCLUE THE NEXT LINE TO SAVE TO FILE
dev.off()

save(MEs, moduleLabels, moduleColors, geneTree, file= "2021-07-23-BLA-DID2-Network_allSamples_signed_nomerge_RLDfiltered.RData")

# Correlate traits --------------------------------------------------------

#barplot module size

mods_16_100 <- as.data.frame(table(moduleColors))
colnames(mods_16_100) <- c("Module", "NumberGenes")
# mods_5_100_test <- mods_5_100[order(mods_5_100$NumberGenes),]

colors <- names(table(moduleColors))

pdf(file='2021-07-23-BLA-DID2-barplot.pdf', width = 10, height = 8)
ggplot(mods_16_100, aes(x=reorder(`Module`, `NumberGenes`), y = `NumberGenes`)) +
  geom_bar(stat = 'identity', fill = colors, color = "black") +
labs(x = "Module", y = "Number of Genes") +
  theme_bw() + geom_text(label = mods_16_100$NumberGenes, nudge_y = 150)#+
  #scale_y_continuous(expand = c(0,0), limits = c(0, 2500)) +
  #theme(axis.text.x = element_text(angle = 45, hjust = 1))

dev.off()
# #Define number of genes and samples
datTraits$BLA <- NULL
datTraits$CEA <- NULL
nGenes = ncol(datExpr)
nSamples = nrow(datExpr)
#Recalculate MEs with color labels
MEs0 = moduleEigengenes(datExpr, moduleColors)$eigengenes
MEs = orderMEs(MEs0)
moduleTraitCor = cor(MEs, datTraits, use= "p")
moduleTraitPvalue = corPvalueStudent(moduleTraitCor, nSamples)


#Print correlation heatmap between modules and traits
textMatrix= paste(signif(moduleTraitCor, 2), "\n(",
                  signif(moduleTraitPvalue, 1), ")", sep= "")
dim(textMatrix)= dim(moduleTraitCor)
par(mar= c(6, 8.5, 3, 3))


#display the corelation values with a heatmap plot
#INCLUE THE NEXT LINE TO SAVE TO FILE
pdf(file="/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/WGCNA/goodnorm/2021-07-27-BLA-only-heatmap.pdf", width = 10, height = 15)
labeledHeatmap(Matrix= moduleTraitCor,
               xLabels= names(datTraits),
               yLabels= names(MEs),
               ySymbols= names(MEs),
               colorLabels= FALSE,
               colors= blueWhiteRed(50),
               textMatrix= textMatrix,
               setStdMargins= TRUE,
               cex.text= 0.5,
               cex.lab.y = 0.7,
               zlim= c(-1,1),
               main= paste("Module-trait relationships"))
#INCLUE THE NEXT LINE TO SAVE TO FILE
dev.off()


#for m200- get black, green, and red
# moduleColorstable <- table(moduleColors)
# get genes
# genes_key <-  data.frame(colnames(datExpr), moduleColors)
# green_filter <- genes_key %>% filter(moduleColors == 'green')
# green_vec <- as.vector(green_filter$colnames.datExpr.)
# write_lines(green_vec, path = 'gene_lists/green_list.txt')
# # 
# # black
# black_filter <- genes_key %>% filter(moduleColors == 'black')
# black_vec <- as.vector(black_filter$colnames.datExpr.)
# write_lines(black_vec, path = 'gene_lists/black_list.txt')
# # 
# # red
# red_filter <- genes_key %>% filter(moduleColors == 'red')
# red_vec <- as.vector(red_filter$colnames.datExpr.)
# write_lines(red_vec, path = 'gene_lists/red_list.txt')
# # 
# # 
# # 
# turq_filter <- genes_key %>% filter(mergedColors == 'turquoise')
# turq_vec <- as.vector(turq_filter$colnames.datExpr.)
# write_lines(turq_vec, path = 'turq_list.txt')
# 
