INPUT_LOC="/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/gene_lists/de_genes"
for FILE in $INPUT_LOC/*
do
  SHORT_NAME=${FILE##*/}
  SHORT_NAME=${SHORT_NAME##*de_}
  echo "Rscript /stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/scripts/enrichr_scripts/enrichRsetup.R -a $FILE -o /stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/enrichR/ -s $SHORT_NAME" >> /stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/scripts/enrichr_scripts/enrichR_executor
done