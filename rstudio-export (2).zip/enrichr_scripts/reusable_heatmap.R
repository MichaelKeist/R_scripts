#This script reads in the directory in which enrichR results are stored
#and outputs a heatmap of the results
library(ComplexHeatmap)

input_dir <- "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/visualizations/enrichr/WGCNA_modules/new/BNST/WIKI/results"
enrichr_files <- list.files(path = input_dir, full.names = TRUE, pattern = "*.csv")
numpaths <- 5

results_list <- list()
interesting_paths <- c()

#this loop looks at every enrichment result, and stores the top 5 enriched path for every region
for(i in 1:length(enrichr_files)){
  working_result <- read.table(enrichr_files[i], header = TRUE, sep = ",")
  working_result <- working_result[order(working_result$Adjusted.P.value, decreasing = FALSE),]
  interesting_paths <- c(interesting_paths, as.character(working_result$Term[1:numpaths]))
  results_list[[i]] <- working_result
}

#remove duplicate pathways
dup_bool <- duplicated(interesting_paths)
interesting_paths <- interesting_paths[!dup_bool]

hm_frame <- data.frame()
#pull data from each result into one frame, non-measured pathways receive adjusted p-value of 1
for(i in 1:length(interesting_paths)){
  current_path <- interesting_paths[i]
  
}