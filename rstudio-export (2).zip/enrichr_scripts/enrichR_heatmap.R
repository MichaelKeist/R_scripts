#LOADING PACKAGES
library(pheatmap)
library(enrichR)
library(RColorBrewer)
#GETTING ENRICHR DATABASES
dbs <- listEnrichrDbs()
dbs <- c("KEGG_2019_Mouse", "Mouse_Gene_Atlas", "WikiPathways_2019_Mouse")

#GETTING GENE LISTS
did1_bla_genes <- scan("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/gene_lists/did1_BLA_genes", character(), quote="")
did1_cea_genes <- scan("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/gene_lists/did1_CEA_genes_no_outlier", character(), quote="")
did2_bla_genes <- scan("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/gene_lists/did2_BLA_genes", character(), quote="")
did2_cea_genes <- scan("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/gene_lists/did2_CEA_genes_no_outlier", character(), quote="")
gene_list <- list(did1_bla_genes,did1_cea_genes,did2_bla_genes,did2_cea_genes)

#RUNNING ENRICHR
output_list <- list()
for(i in gene_list){
  #to select which db is used: 1=kegg, 2=atlas, 3=wikipathways
  db_selection <- 3
  enriched <- enrichr(i,dbs)
  output_list[length(output_list) + 1] <- enriched[db_selection]
}

#TRIMMING ENRICHR OUTPUT
output_trimmed <- list()
for(i in 1:length(output_list)){
  temp_frame <- output_list[[i]][c(1:10),c("Term","P.value")]
  output_trimmed[length(output_trimmed) + 1] <- list(temp_frame)
}

#GETTING TOP 10 PATHWAYS FROM EACH REGION/LINE
target_pathways <- c()
for(i in 1:length(output_trimmed)){
  for(j in 1:length(output_trimmed[[i]]$Term)){
    target_pathways <- c(target_pathways, output_trimmed[[i]]$Term[j])
  }
}

#REMOVING DUPLICATES
target_pathways <- target_pathways[!duplicated(target_pathways)]

#STARTING HEATMAP
heatmap_frame <- data.frame(term=target_pathways)
which(heatmap_frame$term %in% output_list[[1]]$Term)
heatmap_frame <- heatmap_frame[-11,]
heatmap_frame <- as.data.frame(heatmap_frame)
colnames(heatmap_frame) <- c("term")
heatmap_frame$did1_bla <- -log10((output_list[[1]])$P.value[c(which(output_list[[1]]$Term %in% heatmap_frame$term))])
heatmap_frame <- heatmap_frame[-3,]
heatmap_frame <- as.data.frame(heatmap_frame)
heatmap_frame$did1_cea <- -log10((output_list[[2]])$P.value[c(which(output_list[[2]]$Term %in% heatmap_frame$term))])
heatmap_frame$did2_bla <- -log10((output_list[[3]])$P.value[c(which(output_list[[3]]$Term %in% heatmap_frame$term))])
#rows had to be removed, as not all groups had results for that term
heatmap_frame$did2_cea <- -log10((output_list[[4]])$P.value[c(which(output_list[[4]]$Term %in% heatmap_frame$term))])
which(heatmap_frame$term %in% output_list[[1]]$Term)

rownames(heatmap_frame) <- heatmap_frame$term
heatmap_frame$term <- NULL

breakList <- seq(0, 3, by=.5)
rownames(heatmap_frame)[4] <- "Cholesterol metabolism WP4346"

pheatmap(heatmap_frame,
         treeheight_col = 10,
         treeheight_row = 0,
         cluster_rows = T, 
         #cluster_cols = F, fontsize_row = 10, show_colnames = T,
         #labels_col =  c("HDID1", "HSNpt"),
         #labels_row = rownames(heatmap_frame), angle_col = 0,
         breaks = breakList,
         color = colorRampPalette(rev(brewer.pal(n = 7, name = "RdYlBu")))(length(breakList)),
         show_rownames = T,  border_color = F, fontsize_col = 10, main = "EnrichR WikiPathways -log(P-value)")

