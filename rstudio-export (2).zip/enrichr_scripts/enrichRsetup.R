#this script reads in a gene list from the command line, and outputs
#enrichR results and visualizations
library(getopt)
library(readr)
library(enrichR)
library(enrichplot)
library(jpeg)
library(biomaRt)

#getting command line options
spec = matrix(c(
  'gene_list', 'a', 2, "character",
  'output_loc', 'o', 2, "character",
  'shortname', 's', 2, "character"
), byrow=TRUE, ncol=4)
opt = getopt(spec)
shortname <- opt$shortname
output_loc <- opt$output_loc

dot_remover <- function(input){
  return(strsplit(input,"\\.")[[1]][1])
}
#running enrichR
genes <- read_lines(opt$gene_list)
genes <- as.character(lapply(genes, dot_remover))
mart <- biomaRt::useMart(biomart = "ENSEMBL_MART_ENSEMBL",
                         dataset = "mmusculus_gene_ensembl",
                         host = "http://www.ensembl.org")
#, "kegg_enzyme"
genes <- getBM(filters = "ensembl_gene_id",
               attributes = c("ensembl_gene_id","mgi_symbol"),
               values = genes,
               mart = mart)
genes <- genes$mgi_symbol
#dbs <- listEnrichrDbs()
#dbs <- c("KEGG_2019_Mouse", "Mouse_Gene_Atlas", "WikiPathways_2019_Mouse")
dbs_atlas <- c("Mouse_Gene_Atlas")
enriched_atlas <- enrichr(genes, dbs_atlas)
output_atlas <- enriched_atlas[[1]]

dbs_wiki <- c("WikiPathways_2019_Mouse")
enriched_wiki <- enrichr(genes, dbs_wiki)
output_wiki <- enriched_wiki[[1]]

dbs_kegg <- c("KEGG_2019_Mouse")
enriched_kegg <- enrichr(genes, dbs_kegg)
output_kegg <- enriched_kegg[[1]]

#writing outputs
output_frame_name <- paste(output_loc,shortname,sep = "")
write.csv(output_atlas, paste(output_frame_name, "_atlas", sep = ""))
write.csv(output_wiki, paste(output_frame_name, "_wiki", sep = ""))
write.csv(output_kegg, paste(output_frame_name, "_kegg", sep = ""))

#plot_name <- paste(output_loc,shortname, ".jpg", sep = "")
#jpeg(filename = plot_name, width = 10, height = 6, units = "in", quality = 100, res = 150)
#plotEnrich(output, showTerms = 10, orderBy = "P.Value", numChar = 35)
#dev.off()

#saving these plots as 6 x 10 pdfs has worked pretty well for scaling
