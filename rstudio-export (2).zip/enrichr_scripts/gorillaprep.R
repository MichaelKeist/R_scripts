gorillain <- fread("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/currentlyuseful/did1_BLA.csv", header = TRUE)
write_lines(gorillain$V1, "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/currentlyuseful/did1_BLA_gorilla.txt")

z <- fread("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/countsframe.csv", header = TRUE)
