library(viridis)
library(MASS)
library(biomaRt)
#density stuff gotten from https://slowkow.com/notes/ggplot2-color-by-density/
get_density <- function(x, y, ...) {
  dens <- MASS::kde2d(x, y, ...)
  ix <- findInterval(x, dens$x)
  iy <- findInterval(y, dens$y)
  ii <- cbind(ix, iy)
  return(dens$z[ii])
}
dot_remover <- function(input){
  return(strsplit(input,"\\.")[[1]][1])
}
file_vec <- list.files("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value", full.names = T)
region_vec <- c()
line_vec <- c()
count <- 1
#setting up correct sample identifiers
for(item in file_vec){
  holder <- strsplit(item, "/")[[1]][length(strsplit(item, "/")[[1]])]
  region_vec[count] <- strsplit(holder, "_")[[1]][2]
  line_vec[count] <- strsplit(holder, "_")[[1]][1]
  count <- count + 1
}
#reading DESeq tables
count <- 1
for(item in file_vec){
  holder <- read.csv(item)
  holder <- holder[,c("X", "baseMean", "log2FoldChange", "pvalue", "padj")]
  holder$region <- rep(region_vec[count], length(rownames(holder)))
  holder$line <- rep(line_vec[count], length(rownames(holder)))
  if(count != 1){
    data <- rbind(data, holder)
  }else{
    data <- holder
  }
  count <- count + 1
}
#######NEXT SECTION WAS FOR COMPARING TO LIST OF NEURO-IMMUNE GENES, NO LONGER NEEDED, BUT KEEPING FOR LATER
#data$log_pval <- log10(data$pvalue)
#data$X <- as.character(lapply(as.character(data$X), dot_remover))
##getting the neuro genes
#neuro_genes <- scan("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/gene_lists/final_INA_genes_plus_mouse.txt",
#                    what = character())
##need mgi versions
#genes <- read.csv("~/massive_ensembl_to_mgi.csv")
#genes$X <- NULL
#genes$mgi_symbol <- tolower(genes$mgi_symbol)
#genes <- genes[!duplicated(genes$mgi_symbol),]
#genes <- genes[which(genes$mgi_symbol %in% neuro_genes),]
#data$neuro <- is.element(data$X, genes$ensembl_gene_id)
#data <- data[order(data$neuro),]
#data$sig_and_neuro <- data$neuro & data$Significant
#data <- data[order(data$sig_and_neuro),]
#adding in the names of neuro genes so it's not just ensembl names
#neuro_names <- c()
#count <- 1
#for(item in data$X){
#  if(is.element(item, genes$ensembl_gene_id)){
#    neuro_names[count] <- genes$mgi_symbol[which(genes$ensembl_gene_id == item)]
#  }else{
#    neuro_names[count] <- "NA"
#  }
#  count <- count + 1
#}
#data$neuro_name <- neuro_names
data$Significant <- data$padj < 0.05
data$identity <- paste(data$X, data$line, data$region, sep = "_")
data$X <- as.character(lapply(as.character(data$X), FUN = dot_remover))
#########FINDING CON/DISCORDANCE ACROSS DID1 & DID2
cordance <- c()
for(i in 1:length(rownames(data))){
  #the pvalue check is needed because for some ungodly reason, there are NA values
  #for 260 did1BLA genes (they have every other value filled though)
  #0.002273748 is the largest p-value (non adjusted) in the did1BLA group to have
  #sig. padj
  if(is.na(data$padj[i])){
    if(data$pvalue[i] <= 0.002273748){
      data$Significant[i] <- TRUE
    }else{
      data$Significant[i] <- FALSE
    }
  }
  if(data$Significant[i] == TRUE){
    current_identity <- data$identity[i]
    current_l2fc <- data$log2FoldChange[i]
    #looking for gene measured in same region, different line
    if(grepl("_did1_", current_identity)){
      next_identity <- str_replace(current_identity, "_did1_", "_did2_")
    }else{
      next_identity <- str_replace(current_identity, "_did2_", "_did1_")
    }
    next_index <- which(data$identity == next_identity)
    if(length(next_index != 0)){
      if(data$Significant[next_index] == TRUE){
        next_l2fc <- data$log2FoldChange[next_index]
        if(sign(current_l2fc) == sign(next_l2fc)){
          cordance[i] <- "Concordant"
        }else{
          cordance[i] <- "Discordant"
        }
      }else{
        cordance[i] <- "N/A"
      }
    }else{
      cordance[i] <- "N/A"
    }
  }else{
    cordance[i] <- "N/A"
  }
}
data$cordance <- cordance
data$log_pval <- log10(data$padj)
data$log_pval <- replace(data$log_pval, data$log_pval == -Inf, 0)
data$log_pval <- replace(data$log_pval, data$log_pval == Inf, 200)
#need to order data by something other than cordance to prevent one group overlapping others
data <- data[order(data$X),]
#that was WAY more difficult than it should've been. I wanted to make
#a recursive solution but the stack limit stopped me :(
#starting plot
#at the moment, labeling just makes the plot hard to interpret on the poster, so I'll skip doing so for now
theme_set(cowplot::theme_cowplot())
ggplot(data, aes(log2FoldChange, log_pval, color = cordance)) +
  geom_point(alpha = 0.3) +
  facet_wrap(~region) +
  scale_y_reverse()+
  scale_color_manual(values=c("#00A087","#E64B35","#5d616b"), breaks = c("Concordant", "Discordant", "N/A")) +
  labs(color = "Con/Discordance", title = "Gene Expression Volcano Plots") +
  ylab("Log(adjusted p-value)") + xlab("Log2(fold change)") +
  theme(text = element_text(size = 20)) 
data <- remove_missing(data)
data <- data[order(data$region),]
holder <- data[data$region == "BLA",]
density <- get_density(holder$log2FoldChange, holder$log_pval, n = 100)
holder <- data[data$region == "BNST",]
density <- c(density, get_density(holder$log2FoldChange, holder$log_pval, n = 100))
holder <- data[data$region == "CEA",]
density <- c(density, get_density(holder$log2FoldChange, holder$log_pval, n = 100))
holder <- data[data$region == "NAC",]
density <- c(density, get_density(holder$log2FoldChange, holder$log_pval, n = 100))
holder <- data[data$region == "PFC",]
density <- c(density, get_density(holder$log2FoldChange, holder$log_pval, n = 100))
holder <- data[data$region == "VTA",]
density <- c(density, get_density(holder$log2FoldChange, holder$log_pval, n = 100))
ggplot(data, aes(log2FoldChange, log_pval, color = density)) +
  geom_point() +
  scale_color_viridis() +
  scale_y_reverse() +
  facet_wrap(~region)