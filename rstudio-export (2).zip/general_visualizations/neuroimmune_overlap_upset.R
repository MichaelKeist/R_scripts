#this script will read in the neuro-immune genes and make an upsetR overlap plot with the sig genes in each sample group
library(UpSetR)

dot_remover <- dot_remover <- function(input){
  return(strsplit(input,"\\.")[[1]][1])
}

file_vec <- list.files("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value", full.names = TRUE)
simple_vec <- list.files("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value")
names_vec <- c()
count <- 1
for(name in simple_vec){
  names_vec[count] <- paste(strsplit(name, "_")[[1]][1], strsplit(name, "_")[[1]][2], sep = "_")
  count <- count + 1
}

frame_list <- list()
count <- 1
for(file in file_vec){
  frame_list[[count]] <- read.csv(file)
  count <- count + 1
}
upset_list <- list()
count <- 1
for(frame in frame_list){
  upset_list[[names_vec[count]]] <- as.character(frame$X[frame$padj < 0.05])
  count <- count + 1
}
#IMPORTANT - i just noticed just how many significant genes there are in each sample group
#given that there are upwards of 8000 significant genes in some groups, I dont think finding overlaps
#is going to be as interesting as I previously thought