#combines VTA annotation data with annot.csv
vta_line <- c()
vta_region <- c()
vta_sex <- c()
count <- 1
for(sample in vta_samples){
  if(substr(sample, 5, 5) == "F"){
    vta_sex[count] <- "Female"
  }else{
    vta_sex[count] <- "Male"
  }
  vta_region[count] <- "VTA"
  if(substr(sample, 4, 4) == "1"){
    vta_line[count] <- "DID1"
  }else if(substr(sample, 4, 4) == "2"){
    vta_line[count] <- "DID2"
  }else{
    vta_line[count] <- "HSNp"
  }
  count <- count + 1
}

region <- c(as.character(annot$region), as.character(vta_region))
sex <- c(as.character(annot$sex), as.character(vta_sex))
line <- c(as.character(annot$line), as.character(vta_line))
sample <- c(as.character(rownames(annot)), as.character(vta_samples))

variances <- rowVars(as.matrix(counts))
variances <- variances[[1]]

counts$variance <- as.numeric(variances)
counts$variance[!is.numeric(counts$variance)] <- 0
counts <- counts[order(counts$variance, decreasing = TRUE),]

#get top 10% variance
counts <- counts[c(1:2068),]

write.csv(new_annot, file = "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/all_brain_regions_tables/for_pca/annot_new.csv")
