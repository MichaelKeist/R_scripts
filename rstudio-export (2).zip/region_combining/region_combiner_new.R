#This script combines counts frames across regions
#unmeasured genes will be populated with zeros
library(data.table)

bnst_counts <- as.data.frame(fread("/stor/work/WCAAR/scratch/eke_scratch/Angela/DESeq_by_tissue/BNST/2020-11-25-normalizedcounts.csv"))
nac_counts <- as.data.frame(fread("/stor/work/WCAAR/scratch/eke_scratch/Angela/DESeq_by_tissue/NAC/2020-12-01-normalizedcounts-NAC.csv"))
pfc_counts <- as.data.frame(fread("/stor/work/WCAAR/scratch/eke_scratch/Angela/DESeq_by_tissue/PFC/2020-12-01-normalizedcounts-PFC.csv"))
bla_and_cea_counts <- as.data.frame(fread("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/BLA_CEA_tables/all_ddsnormalized.csv"))
vta_counts <- as.data.frame(fread("/stor/scratch/WCAAR/eke_scratch/Angela/DESeq_by_tissue/VTA/2020-12-06-normalizedcounts-VTA.csv"))

bnst_genes <- bnst_counts$V1
nac_genes <- nac_counts$V1
pfc_genes <- pfc_counts$V1
bla_and_cea_genes <- bla_and_cea_counts$V1
vta_genes <- vta_counts$V1

union_genes <- union(bnst_genes,nac_genes)
union_genes <- union(union_genes,pfc_genes)
union_genes <- union(union_genes,bla_and_cea_genes)
union_genes <- union(union_genes,vta_genes)

#populating unmeasured genes with zeros
all_tables <- list(bnst_counts,nac_counts,pfc_counts,bla_and_cea_counts,vta_counts)
count = 1
while(count <= length(all_tables)){
  all_tables[[count]]$variance <- NULL
  all_tables[[count]] <- all_tables[[count]][(which(all_tables[[count]]$V1 %in% union_genes)),]
  all_tables[[count]]$X <- as.character(all_tables[[count]]$V1)
  for(gene in union_genes[-c(which(union_genes %in% all_tables[[count]]$V1))]){
    new_row <- as.list(c(gene, rep(0, length(colnames(all_tables[[count]])) - 1)))
    new_row_df <- data.frame(new_row)
    colnames(new_row_df) <- colnames(all_tables[[count]])
    all_tables[[count]] <- rbind(all_tables[[count]],new_row_df)
    all_tables[[count]]$V1[length(all_tables[[count]]$V1)] <- gene
  }
  rownames(all_tables[[count]]) <- all_tables[[count]]$V1
  all_tables[[count]]$V1 <- NULL
  count <- count + 1
}

x <- cbind(all_tables[[1]],all_tables[[2]],all_tables[[3]],all_tables[[4]],all_tables[[5]])
x$X <- NULL
write.csv(x, file = "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/all_brain_regions_tables/counts_new.csv")
