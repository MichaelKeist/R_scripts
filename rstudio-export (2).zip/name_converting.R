dot_remover <- function(input){
  return(strsplit(input,"\\.")[[1]][1])
}

formatted_input <- as.character(lapply(input_list, FUN = dot_remover))

mart <- biomaRt::useMart(biomart = "ENSEMBL_MART_ENSEMBL",
                         dataset = "mmusculus_gene_ensembl",
                         host = "http://www.ensembl.org")

genes <- getBM(filters = "ensembl_gene_id",
               attributes = c("ensembl_gene_id","entrezgene_id"),
               values = formatted_input, 
               mart = mart)