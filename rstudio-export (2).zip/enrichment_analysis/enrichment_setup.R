#This script takes the lists of DEGs and runs them through the set of enrichment analyses found here:
#https://yulab-smu.top/biomedical-knowledge-mining-book/enrichplot.html?q=heat#heatmap-like-functional-classification'

#loading necessary libraries
library('getopt')
library(DOSE)
library(enrichplot)
library(biomaRt)
library(enrichR)
library(clusterProfiler)
library("pathview")

#BiocManager::install("rWikiPathways", update = TRUE)
library("rWikiPathways")
#BiocManager::install("graphite")
library(graphite)
#BiocManager::install("GeneTonic")

spec = matrix(c(
  'input_list', 'i', 1, 'character'
), byrow=TRUE, ncol=4)
opt = getopt(spec)

#input_list <- opt$input_list

#converting ensemble to entrez
dot_remover <- function(input){
  return(strsplit(input,"\\.")[[1]][1])
}

input_list <- readLines("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/gene_lists/de_genes/de_did2_BNST")
deseq_frame <- read.table("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value/did2_BNST_output.csv", header = TRUE, sep = ",")
formatted_input <- as.character(lapply(input_list, FUN = dot_remover))
if(!("ensembl_gene_id" %in% colnames(deseq_frame))){
  colnames(deseq_frame)[1] <- "ensembl_gene_id"
  deseq_frame <- deseq_frame[which(deseq_frame$ensembl_gene_id %in% input_list),]
  deseq_frame$ensembl_gene_id <- formatted_input
}else{
  deseq_frame <- deseq_frame[which(deseq_frame$ensembl_gene_id %in% formatted_input),]
}
mart <- biomaRt::useMart(biomart = "ENSEMBL_MART_ENSEMBL",
                         dataset = "mmusculus_gene_ensembl",
                         host = "http://www.ensembl.org")
#, "kegg_enzyme"
genes <- getBM(filters = "ensembl_gene_id",
               attributes = c("ensembl_gene_id","entrezgene_id"),
               values = formatted_input,
               mart = mart)

dup_vec <- duplicated(genes$ensembl_gene_id)
genes <- genes[!dup_vec,]
dup_vec <- duplicated(genes$entrezgene_id)
genes <- genes[!dup_vec,]
genes <- genes[-which(is.na(genes$entrezgene_id)),]
deseq_frame <- deseq_frame[which(deseq_frame$ensembl_gene_id %in% genes$ensembl_gene_id),]
rownames(deseq_frame) <- deseq_frame$ensembl_gene_id
rownames(genes) <- genes$ensembl_gene_id
combined_frame <- merge(deseq_frame, genes, by=0, all=TRUE)
# genes <- getBM(filters = "ensembl_gene_id",
#                attributes = c("ensembl_gene_id","mgi_symbol"),
#                values = formatted_input,
#                mart = mart)
genes <- genes$entrezgene_id
geneList <- (-log(combined_frame$padj, base=10)) * sign(combined_frame$log2FoldChange)
geneList <- setNames(geneList, combined_frame$entrezgene_id)
geneList <- sort(geneList, decreasing = TRUE)

#beginning chapter 15 enrichment analysis
enriched_KEGG <- enrichKEGG(genes, organism = "mmu", keyType = "ncbi-geneid", pvalueCutoff = 0.05)
jpeg(filename = "~/test_enrichment.jpg",
     width = 8, height = 8, units = "in", quality = 100,
     res = 150)
barplot(enriched_KEGG, showCategory=20)
dev.off()
enriched_gse_KEGG <- gseKEGG(geneList, organism = "mmu", keyType = "ncbi-geneid", pvalueCutoff = 1)
saveRDS(enriched, file="~/testrds")
enriched <- load("~/testrds")
biocarta_paths <- pathways("mmusculus", "BioCarta")
# wp.hs.gmt <- rWikiPathways::downloadPathwayArchive(organism="Homo sapiens", format = "gmt")
# dbs <- c("WikiPathways_2019_Mouse")
# enriched_wiki <- enrichr(symbols, dbs)


#beginning chapter 7 enrichment analysis
mouse <- search_kegg_organism('Mus musculus', by='scientific_name')
kk <- enrichKEGG(gene         = genes,
                 organism     = 'mmu',
                 pvalueCutoff = 0.05)
head(kk)

kk2 <- gseKEGG(geneList     = geneList, keyType = "ncbi-geneid",
               organism     = 'mmu',
               minGSSize    = 2,
               pvalueCutoff = 0.99,
               verbose      = FALSE)

mkk <- enrichMKEGG(gene = genes,
                   organism = 'mmu',
                   pvalueCutoff = 1,
                   qvalueCutoff = 1)

mkk2 <- gseMKEGG(geneList = geneList,
                 organism = 'mmu',
                 pvalueCutoff = 1)

browseKEGG(kk, 'mmu03040')

mmu05022 <- pathview(gene.data  = geneList,
                     pathway.id = "mmu05022",
                     species    = "mmu",
                     limit      = list(gene=c(-10,10), cpd=1))


