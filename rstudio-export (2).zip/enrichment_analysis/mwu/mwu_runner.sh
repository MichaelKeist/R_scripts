#!/bin/bash
for FILE in ./*
do
	if [[ $FILE == *did* ]]
	then
		echo $FILE
		SIMPLE=${FILE##*/}
		echo "Rscript GO_MWU.R -i $SIMPLE -a mmu_go_annot.mgi -d goslim_generic.obo -n CC" >> go_mwu_exe
	fi
done
