#!/bin/bash
LOC="/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/scripts/enrichment_analysis/mwu"
for FILE in $LOC/*
do
	if [[ "$FILE" == *"did"* ]]
	then
		SIMPLE_NAME=${FILE::-12}
		echo "gene,logfoldchange" > $SIMPLE_NAME
		awk 'NR!=1' $FILE >> $SIMPLE_NAME
	fi
done
