#reads in go-mwu results and creates heatmap
library(pheatmap)
library(RColorBrewer)
division <- "CC"

order_check <- function(fac1, fac2){
  if(length(fac1) == length(fac2)){
    for(i in 1:length(fac1)){
      if(fac1[i] != fac2[i]){
        return(FALSE)
      }
    }
  }else{
    return(FALSE)
  }
  return(TRUE)
}

get_simple_name <- function(file){
  simple_name <- strsplit(file, "/")
  simple_name <- simple_name[[1]]
  simple_name <- simple_name[length(simple_name)]
  simple_name <- strsplit(simple_name, paste(division,"_", sep = ""))[[1]][2]
}

frame_list <- list()
file_vec <- list.files("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/scripts/enrichment_analysis/mwu/CC_results", full.names = T, pattern = "MWU*")
count <- 1
for(file in file_vec){
  holder <- read.table(file, sep = " ", header = T)
  frame_list[[count]] <- holder
  count <- count + 1
}

hm_frame <- data.frame(row.names = 1:length(frame_list[[1]]$name))
hm_frame$name <- frame_list[[1]]$name
name_vec <- c()

count <- 1
for(file in file_vec){
  name_vec[count] <- get_simple_name(file)
  count <- count + 1
  
}

pval_vec <- c()
count <- 1
for(frame in frame_list){
  #only the terms present in the first frame of frame_list will be included in the heatmap frame. (should be fine since only cytokinesis will be left out and it had very high p-values in all cases)
  new_col <- -log10((frame$p.adj[frame$name %in% hm_frame$name])) * sign(frame$delta.rank[frame$name %in% hm_frame$name])
  hm_frame$placehold <- new_col
  colnames(hm_frame)[count+1] <- name_vec[count]
  count <- count + 1
}

rownames(hm_frame) <- hm_frame$name
hm_frame$name <- NULL
breaks <- seq(-2,2,by=0.05)
pheatmap(hm_frame, cluster_rows = hc, breaks = breaks,
         color = colorRampPalette(rev(brewer.pal(n = 7, name = "RdYlBu")))(length(breaks)))
