#This file reads in deseq2 outputs, and will return log(foldchange) data for genes, as recommended in:
#https://github.com/z0on/GO_MWU
table_list <- list()
dot_remover <- function(input){
  return(strsplit(input,"\\.")[[1]][1])
}

file_loc <- "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value"
file_vec_simple <- list.files(file_loc)
file_vec <- list.files(file_loc, full.names = T)

count <- 1
for(file in file_vec){
  holder <- read.csv(file)
  table_list[[count]] <- holder
  names(table_list)[count] <- file_vec_simple[count]
  count <- count + 1
}

#getting mgi symbols for BLA and CEA genes
mart <- biomaRt::useMart(biomart = "ENSEMBL_MART_ENSEMBL",
                         dataset = "mmusculus_gene_ensembl",
                         host = "http://www.ensembl.org")

count <- 1
for(table in table_list){
  if(grepl("BLA", names(table_list)[count]) | grepl("CEA", names(table_list)[count])){
    ens_genes <- as.character(table$X)
    ens_genes <- as.character(lapply(ens_genes, FUN = dot_remover))
    table$X <- ens_genes
    genes <- getBM(filters = "ensembl_gene_id",
                   attributes = c("ensembl_gene_id","mgi_symbol"),
                   values = ens_genes,
                   mart = mart)
    table <- table[which(table$X %in% genes$ensembl_gene_id),]
    table$mgi_symbol <- genes$mgi_symbol
    table_list[[count]] <- table
  }
  count <- count + 1
}

file_vec_simple <- as.character(lapply(file_vec_simple, FUN = dot_remover))
count <- 1
for(table in table_list){
  output <- table[,c("mgi_symbol", "log2FoldChange")]
  write.csv(output, row.names = F, col.names = F,
            file = paste("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/scripts/enrichment_analysis/mwu/", file_vec_simple[count], "ranks", sep = ""),
            quote = F)
  count <- count + 1
}








