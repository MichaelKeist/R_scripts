#gene ontologies were obtained from: http://www.informatics.jax.org/downloads/reports/index.html#go
#This script will get the gene ontology info and output formatted data to a file
ontology_file = open("gene_association.mgi", "r")
output_file = open("mmu_go_annot.mgi", "w")
seen_genes = []
line_list = []
current_onts = []
count = 0
for line in ontology_file:
    if count > 2:
        internal_list = line.split("\t")
        #internal_list[4] = internal_list[4][3:]
        internal_list = [internal_list[2], internal_list[4]]
        if internal_list[0] not in seen_genes:
            if len(seen_genes) != 0:
                output_file.write("\n")
                current_onts = []
            output_file.write(internal_list[0] + "\t" + internal_list[1])
            current_onts.append(internal_list[1])
            seen_genes.append(internal_list[0])
        else:
            if internal_list[1] not in current_onts:
                output_file.write(";" + internal_list[1])
                current_onts.append(internal_list[1])
    count += 1
ontology_file.close()
output_file.close()
