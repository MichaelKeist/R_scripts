#This script takes the lists of DEGs and runs them through the set of enrichment analyses found here:
#https://yulab-smu.top/biomedical-knowledge-mining-book/enrichplot.html?q=heat#heatmap-like-functional-classification'
#wikipathways guide found at
#https://bioconductor.org/packages/release/bioc/vignettes/rWikiPathways/inst/doc/Pathway-Analysis.html#4_Enrichment

#loading necessary libraries
library('getopt')
library(DOSE)
library(enrichplot)
library(biomaRt)
library(enrichR)
library(clusterProfiler)
library("pathview")
library(clusterProfiler)
library(rWikiPathways)
library(dplyr)

spec = matrix(c(
  'input_list', 'i', 1, 'character',
  'output_dir', 'o', 1, 'character',
  'output_prefix', 'p', 1, 'character',
  'deseq_loc', 'd', 1, 'character',
  'cutoff', 'c', 1, 'numeric',
  'min_genes', 'm', 2, 'numeric'
), byrow=TRUE, ncol=4)
opt = getopt(spec)

input_list <- opt$input_list
output_dir <- opt$output_dir
prefix <- opt$output_prefix
deseq_loc <- opt$deseq_loc
cutoff <- opt$cutoff
if(is.null(opt$min_genes)){
  min_genes <- 10
}else{
  min_genes <- opt$min_genes
}

#converting ensemble to entrez
dot_remover <- function(input){
  return(strsplit(input,"\\.")[[1]][1])
}

#input data used for testing the script
input_list <- "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/gene_lists/de_genes/de_did2_VTA"
output_dir <- "/stor/home/mk37825/testing"
prefix <- "did2_VTA"
deseq_loc <- "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value/did2_VTA_output.csv"


cutoff <- 1

#input_list <- readLines(input_list)
#formatted_input <- as.character(lapply(input_list, FUN = dot_remover))
deseq_frame <- read.table(file = deseq_loc, header = TRUE, sep = ",")
deseq_frame$X <- as.character(deseq_frame$X)
deseq_frame$X <- as.character(lapply(deseq_frame$X, FUN = dot_remover))
input_list <- deseq_frame$X
formatted_input <- input_list
#this next bit is needed because the deseq outputs are slightly different for BLA and CEA
if(!("mgi_symbol" %in% colnames(deseq_frame))){
  colnames(deseq_frame) <- c("ensembl_gene_id", "baseMean", "log2FoldChange", "lfcSE", "stat", "pvalue", "padj")
  deseq_frame <- deseq_frame[which(deseq_frame$ensembl_gene_id %in% input_list),]
  selected_genes <- as.character(deseq_frame$ensembl_gene_id)
  new_gene_names <- as.character(lapply(selected_genes, FUN = dot_remover))
  deseq_frame$ensembl_gene_id <- new_gene_names
  
  mart <- biomaRt::useMart(biomart = "ENSEMBL_MART_ENSEMBL",
                           dataset = "mmusculus_gene_ensembl")
  genes <- getBM(filters = "ensembl_gene_id",
                 attributes = c("ensembl_gene_id","mgi_symbol"),
                 values = formatted_input,
                 mart = mart)
  deseq_frame <- merge(deseq_frame, genes, by = "ensembl_gene_id")
}else{
  deseq_frame <- deseq_frame[which(deseq_frame$ensembl_gene_id %in% formatted_input),]
  genes <- data.frame(ensembl_gene_id = deseq_frame$ensembl_gene_id, mgi_symbol = deseq_frame$mgi_symbol)
}

dup_vec <- duplicated(genes$ensembl_gene_id)
genes <- genes[!dup_vec,]
dup_vec <- duplicated(genes$ensembl_gene_id)
genes <- genes[!dup_vec,]
if(anyNA(genes$mgi_symbol)){
  genes <- genes[-which(is.na(genes$ensembl_gene_id)),]
}
deseq_frame <- deseq_frame[which(deseq_frame$ensembl_gene_id %in% genes$ensembl_gene_id),]
rownames(deseq_frame) <- deseq_frame$ensembl_gene_id
rownames(genes) <- genes$ensembl_gene_id
combined_frame <- merge(deseq_frame, genes, by=0, all=TRUE)
# genes <- getBM(filters = "ensembl_gene_id",
#                attributes = c("ensembl_gene_id","mgi_symbol"),
#                values = formatted_input,
#                mart = mart)
genes <- genes$entrezgene_id
#if the log operation creates a + or - inf,
#im replacing it with + or - 200
geneList <- (-log(combined_frame$padj, base=10)) * sign(combined_frame$log2FoldChange)
geneList <- setNames(geneList, combined_frame$mgi_symbol.x)
geneList <- sort(geneList, decreasing = TRUE)
geneList[which(geneList == Inf)] <- 200
geneList[which(geneList == -Inf)] <- -200
genes[which(genes == Inf)] <- 200
genes[which(genes == -Inf)] <- -200

#making dataframe representing the neuroimmune genes
neuro_genes <- scan("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/gene_lists/final_INA_genes_plus_mouse.txt", what = character())
term2gene <- data.frame(term = rep("Neuro-Immune", length(neuro_genes)), gene = neuro_genes)
#adder_vec <- names(geneList)[names(geneList) %in% term2gene$term]
term2name <- data.frame(term = term2gene$term, name = term2gene$term)
#need to make geneList names lowercase so it matches the neuroimmune genes
names(geneList) <- tolower(names(geneList))
#starting the analysis
if(all(is.finite(geneList))){
  gsea_out <- GSEA(geneList = geneList, TERM2GENE = term2gene, pvalueCutoff = 1,
                   minGSSize = 0, maxGSSize = 1000)
  #saveRDS(gseenriched, file = paste(output_dir,"/",prefix,"_gseenriched", sep = ""))
}
gseaplot2(gsea_out, geneSetID = "Neuro-Immune", pvalue_table = T)

#to do: enrichKEGG, gseKEGG

#data(geneList)
#testing
#rand gene size must change with every brain region since some of the neuro-immune genes won't
#be measured in every sample
rand_genes <- sample(names(geneList), 326, replace = F)
rterm2gene <- data.frame(term = rep("random_genes", length(rand_genes)), gene = rand_genes)
rgsea_out <- GSEA(geneList = geneList, TERM2GENE = rterm2gene, pvalueCutoff = 1,
                 minGSSize = 0, maxGSSize = 1000)
gseaplot2(rgsea_out, geneSetID = "random_genes", pvalue_table = T)
