#This script will make some sort of volcano-like plot to display gsea results
#variables to plot: enrichment score (x-axis), p-value (y-axis), brain region (color), some sort of consensus (unknown)
library(UpSetR)
#load data
frame_list <- list()
file_vec <- list.files(path = "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/visualizations/enrichment/no_cutoff_all_genes",
                       pattern = "*gse*", full.names = TRUE)
count <- 1
for(file in file_vec){
  frame_list[[count]] <- readRDS(file)@result
  count <- count + 1
}

#grab interesting info, add to a consolidated dataframe
region_vec_short <- c()
line_vec_short <- c()
for(group in file_vec){
  short_group <- strsplit(group, "/")[[1]][length(strsplit(group, "/")[[1]])]
  region <- strsplit(short_group, "_")[[1]][2]
  #calling the variable xline because there's a function called line
  xline <- strsplit(short_group, "_")[[1]][1]
  region_vec_short <- c(region_vec_short, region)
  line_vec_short <- c(line_vec_short, xline)
}
term_vec <- c()
score_vec <- c()
pval_vec <- c()
region_vec <- c()
line_vec <- c()
count <- 1
for(frame in frame_list){
  term_vec <- c(term_vec, frame$Description)
  score_vec <- c(score_vec, frame$enrichmentScore)
  pval_vec <- c(pval_vec, frame$pvalue)
  region_vec <- c(region_vec, rep(region_vec_short[count], length(frame$Description)))
  line_vec <- c(line_vec, rep(line_vec_short[count], length(frame$Description)))
  count <- count + 1
}

main_table <- data.frame(term = term_vec, score = score_vec, pval = pval_vec, region = region_vec, line = line_vec)
main_table$sig <- main_table$pval < 0.05

#new code here
main_table$log_pval <- log10(main_table$pval)

#beginning plotting and analysis
#plot1
theme_set(cowplot::theme_cowplot())
ggplot(main_table, aes(score, log_pval, color = sig, shape = line)) +
  geom_point(alpha = 0.7) +
  facet_wrap(~region) +
  #ggthemes::scale_color_colorblind()+
  scale_y_reverse()+
  scale_color_manual(values=c("#5d616b","#E64B35"))

#subset to analyze only significant observations (pval < 0.05)
sig_table <- main_table[main_table$pval < 0.05,]
#plot2
ggplot(sig_table, aes(score, pval, color = region, shape = line)) +
  geom_point() #looks like there were more did2s in the upreg group, making plot 3 to verify
  

# enrichment score is no longer all that interesting here (if you ask me), replacing it with sign of enrichment score
sig_signed_table <- sig_table
sig_signed_table$score <- factor(sign(sig_signed_table$score))
#plot3
ggplot(sig_signed_table, aes(fill = line, x = score)) +
  geom_bar(position = "stack") +
  labs(title = "Breakdown of Significant Pathways", x = " ", y = "frequency") +
  scale_x_discrete(labels = c("Downregulated", "Upregulated"))

#I want to single out the group of observations in bottom right of plot2
ggplot(sig_table, aes(score, pval, color = region, shape = line)) +
  geom_point() + annotate("rect", xmin = 0.38, xmax = 0.78, ymax = 0.0045, ymin = 0.0005,
                          fill = "red", color = "red", alpha = 0.15)
plot4_table <- sig_table[sig_table$pval < 0.0045 & sig_table$score > 0,]
plot4_table$term <- factor(plot4_table$term)
#plot4
ggplot(plot4_table, aes(score, pval, color = region, shape = line, label = term)) +
  geom_point() + geom_text(vjust = 3, hjust = .6)
#plot5
ggplot(plot4_table, aes(fill = region, x = term, color = line)) +
  geom_bar(position = "stack") +
  scale_color_manual(values = c("did1" = "red", "did2" = "blue")) +
  coord_flip()

#I want to make something like plot5 but on all sig observations
#plot6
plot6_table <- sig_table
ud_vec <- c()
for(val in plot6_table$score){
  if(val >= 0){
    ud_vec <- c(ud_vec, "U")
  }else{
    ud_vec <- c(ud_vec, "D")
  }
}
plot6_table$ud <- factor(ud_vec)
ggplot(plot6_table, aes(fill = region, x = term, color = line)) +
  geom_bar(position = "stack") +
  scale_color_manual(values = c("did1" = "red", "did2" = "blue")) +
  coord_flip()

#making a plot to show change in directionality of pathways
plot7_table <- sig_table
id_vec <- paste(plot7_table$term, plot7_table$region)
plot7_table$id <- id_vec
ggplot(plot7_table, aes(x = line, y = score, group = id, color = region, label = term)) +
  geom_line() + geom_text(data = plot7_table[plot7_table$region == "BLA" & plot7_table$term == "PPAR signaling pathway",])

#I want to make something like plot7 but on all terms (that were observed across line in the same region)
plot8_table <- main_table
id_vec <- paste(plot8_table$term, plot8_table$region)
#plot8
plot8_table$id <- id_vec
ggplot(plot8_table, aes(x = line, y = score, group = id, color = region, label = term)) +
  geom_line()

#want to make plot9 basically plot8 but only including paths that changed signs from did1 to did2 (same region)
plot9_table <- plot8_table
bool_vec <- c()
for(i in 1:length(plot9_table$term)){
  val1 <- plot9_table[i, "score"]
  id <- plot9_table[i, "id"]
  val2 <- plot9_table[-i,]
  val2 <- val2[val2$id == id, "score"]
  if(length(val2) != 0){
    if(sign(val1) != sign(val2)){
      bool_vec <- c(bool_vec, TRUE)
    }else{
      bool_vec <- c(bool_vec, FALSE)
    }
  }else{
    bool_vec <- c(bool_vec, FALSE)
  }
}
plot9_table <- plot9_table[bool_vec,]
#plot9
ggplot(plot9_table, aes(x = line, y = score, group = id, color = region, label = term)) +
  geom_line()

#gonna plot relative frequencies of each brain region in the "sign change" subset
#plot10
ggplot(plot9_table, aes(x = region)) +
  geom_bar()

#next one will be upsetR overlaps of plot10 groups
inlist <- list(BLA = plot9_table[plot9_table$region == "BLA", "term"],
               BNST = plot9_table[plot9_table$region == "BNST", "term"],
               CEA = plot9_table[plot9_table$region == "CEA", "term"],
               NAC = plot9_table[plot9_table$region == "NAC", "term"],
               PFC = plot9_table[plot9_table$region == "PFC", "term"],
               VTA = plot9_table[plot9_table$region == "VTA", "term"])
#plot11
upset(fromList(inlist), order.by = "freq", nsets = 6)

#next, I want to make something like plot9, but with filtering for significance in a less conservative way than
#the filter for plot 7 (if either end point on the plot is significant, it will be shown)
plot12_table <- plot9_table
bool_vec <- c()
for(i in 1:length(plot12_table$term)){
  p1 <- plot12_table[i, "pval"]
  id <- plot12_table[i, "id"]
  p2 <- plot12_table[-i,]
  p2 <- p2[p2$id == id, "pval"]
  if(p1 < 0.05 | p2 < 0.05){
    bool_vec <- c(bool_vec, TRUE)
  }else{
    bool_vec <- c(bool_vec, FALSE)
  }
}
plot12_table <- plot12_table[bool_vec,]
#plot12
ggplot(plot12_table, aes(x = line, y = score, group = id, color = region, label = term)) +
  geom_line() + geom_text(data = plot12_table[plot12_table$pval < 0.005,])
