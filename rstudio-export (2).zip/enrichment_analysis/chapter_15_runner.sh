#!/bin/bash
LIST_DIRECTORY=$'/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/gene_lists/de_genes'
DESEQ_DIRECTORY=$'/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value'
SCRIPT_LOC=$"/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/scripts/enrichment_analysis/chapter_15.R"
COMMAND_LOC=$"/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/scripts/enrichment_analysis/chapter_15_commands"
for GENE_LIST in $LIST_DIRECTORY/*
do
	SAMPLE=${GENE_LIST##*/}
	SAMPLE=${SAMPLE##*de_}
	ENRICHMENT_I=$GENE_LIST
	ENRICHMENT_D=${DESEQ_DIRECTORY}/${SAMPLE}_output.csv
	ENRICHMENT_O=$"/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/visualizations/enrichment"
	ENRICHMENT_P=$SAMPLE
	ENRICHMENT_C=1
	echo "Rscript $SCRIPT_LOC -i $ENRICHMENT_I -d $ENRICHMENT_D -p $ENRICHMENT_P -o $ENRICHMENT_O -c $ENRICHMENT_C" >> $COMMAND_LOC
done
