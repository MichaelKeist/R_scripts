#this script takes in a single enrich result, and outputs a heatmap of pathways colored by their fold chain
#the script doesn't do much more than a simple bar plot, so I probably won't work on it anymore

enrich_result <- readRDS("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/visualizations/enrichment/did2_BNST_enriched")
gsea_result <- readRDS("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/visualizations/enrichment/did2_BNST_gseenriched")
enrich_readable <- setReadable(enrich_result, 'org.Mm.eg.db', 'ENTREZID')
#enrich_readable_termsim <- 

library(ggplot2)
library(cowplot)
library(enrichplot)
library(clusterProfiler)
#install.packages("pairwise_termsim")

# p1 <- cnetplot(enrich_readable, foldChange=geneList)
# ## categorySize can be scaled by 'pvalue' or 'geneNum'
# p2 <- cnetplot(enrich_readable, categorySize="pvalue", foldChange=geneList)
# p3 <- cnetplot(enrich_readable, foldChange=geneList, circular = TRUE, colorEdge = TRUE) 
# theme_set(theme_cowplot())
# 
# jpeg(filename = "cow_did2_bnst.jpg",
#      width = 32, height = 32, units = "in", quality = 100,
#      res = 150)
# plot_grid(p1, p2, p3, ncol=3, labels=LETTERS[1:3], rel_widths=c(.8, .8, 1.2))
# dev.off()

#changing result columns THIS ONE WORKS!!!
col_count = 1
while(col_count <=5){
  path_genes <- as.vector(strsplit(enrich_result@result$geneID[col_count], "/")[[1]])
  path_genes <- sample(path_genes,15)
  string_genes <- paste(path_genes, sep = "/", collapse = "/")
  enrich_result@result$geneID[col_count] <- string_genes 
  #enrich_result[col_count]$geneID <- sample(enrich_result[col_count]$geneID, 50, replace = TRUE)
  col_count = col_count + 1
}
enrich_readable <- setReadable(enrich_result, 'org.Mm.eg.db', 'ENTREZID')
#heatplot(enrich_readable, showCategory=5)
heatplot(enrich_readable, foldChange=geneList, showCategory=5)
#cowplot::plot_grid(p1, p2, ncol=1, labels=LETTERS[1:2])


# #changing geneList (works kinda?)
# geneList <- c(geneList[1:150], geneList[(length(geneList) -150):length(geneList)])
# enrich_result@gene <- enrich_result@gene[which(enrich_result@gene %in% names(geneList))]
# enrich_readable <- setReadable(enrich_result, 'org.Mm.eg.db', 'ENTREZID')
# #heatplot(enrich_readable, showCategory=5)
# heatplot(enrich_readable, foldChange=geneList, showCategory=5)
# #cowplot::plot_grid(p1, p2, ncol=1, labels=LETTERS[1:2])
# 
# 
# #changing geneID (doesnt work)
# geneList <- geneList[1:250]
# enrich_result@result[["geneID"]] <- enrich_result@result[["geneID"]][which(enrich_result@result[["geneID"]] %in% names(geneList))]
# enrich_readable <- setReadable(enrich_result, 'org.Mm.eg.db', 'ENTREZID')
# #heatplot(enrich_readable, showCategory=5)
# heatplot(enrich_readable, foldChange=geneList, showCategory=5)
# #cowplot::plot_grid(p1, p2, ncol=1, labels=LETTERS[1:2])

