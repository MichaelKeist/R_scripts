#This script takes the lists of DEGs and runs them through the set of enrichment analyses found here:
#https://yulab-smu.top/biomedical-knowledge-mining-book/enrichplot.html?q=heat#heatmap-like-functional-classification'
#wikipathways guide found at
#https://bioconductor.org/packages/release/bioc/vignettes/rWikiPathways/inst/doc/Pathway-Analysis.html#4_Enrichment

#loading necessary libraries
library('getopt')
library(DOSE)
library(enrichplot)
library(biomaRt)
library(enrichR)
library(clusterProfiler)
library("pathview")
library(clusterProfiler)
library(rWikiPathways)
library(dplyr)

#from https://rdrr.io/github/wikipathways/rWikiPathways/src/R/readPathwayGMT.R
readPathwayGMT <- function(file) {
  x <- readLines(file)
  res <- strsplit(x, "\t")
  names(res) <- vapply(res, function(y) y[1], character(1))
  res <- lapply(res, "[", -c(1:2))
  
  wp2gene <- stack(res)
  wp2gene <- wp2gene[, c("ind", "values")]
  colnames(wp2gene) <- c("pathway", "gene")
  wp2gene <- tidyr::separate(wp2gene, pathway, c("name","version","wpid","org"), "%")
  return(wp2gene)
}

spec = matrix(c(
  'input_list', 'i', 1, 'character',
  'output_dir', 'o', 1, 'character',
  'output_prefix', 'p', 1, 'character',
  'deseq_loc', 'd', 1, 'character',
  'cutoff', 'c', 1, 'numeric',
  'min_genes', 'm', 2, 'numeric'
), byrow=TRUE, ncol=4)
opt = getopt(spec)

input_list <- opt$input_list
output_dir <- opt$output_dir
prefix <- opt$output_prefix
deseq_loc <- opt$deseq_loc
cutoff <- opt$cutoff
if(is.null(opt$min_genes)){
  min_genes <- 10
}else{
  min_genes <- opt$min_genes
}

#converting ensemble to entrez
dot_remover <- function(input){
  return(strsplit(input,"\\.")[[1]][1])
}

#input data used for testing the script
#input_list <- "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/gene_lists/de_genes/de_did1_BLA"
#output_dir <- "/stor/home/mk37825/testing"
#prefix <- "did1_BLA"
#deseq_loc <- "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value/did1_BLA_output.csv"


cutoff <- 1

#input_list <- readLines(input_list)
#formatted_input <- as.character(lapply(input_list, FUN = dot_remover))
deseq_frame <- read.table(file = deseq_loc, header = TRUE, sep = ",")
deseq_frame$X <- as.character(deseq_frame$X)
deseq_frame$X <- as.character(lapply(deseq_frame$X, FUN = dot_remover))
input_list <- deseq_frame$X
formatted_input <- input_list
#this next bit is needed because the deseq outputs are slightly different for BLA and CEA
if(!("ensembl_gene_id" %in% colnames(deseq_frame))){
  colnames(deseq_frame)[1] <- c("ensembl_gene_id", "baseMean", "log2FoldChange", "lfcSE", "stat", "pvalue", "padj")
  deseq_frame <- deseq_frame[which(deseq_frame$ensembl_gene_id %in% input_list),]
  selected_genes <- as.character(deseq_frame$ensembl_gene_id)
  new_gene_names <- as.character(lapply(selected_genes, FUN = dot_remover))
  deseq_frame$ensembl_gene_id <- new_gene_names
}else{
  deseq_frame <- deseq_frame[which(deseq_frame$ensembl_gene_id %in% formatted_input),]
}
mart <- biomaRt::useMart(biomart = "ENSEMBL_MART_ENSEMBL",
                         dataset = "mmusculus_gene_ensembl",
                         host = "http://www.ensembl.org")
#, "kegg_enzyme"
genes <- getBM(filters = "ensembl_gene_id",
               attributes = c("ensembl_gene_id","entrezgene_id"),
               values = formatted_input,
               mart = mart)

dup_vec <- duplicated(genes$ensembl_gene_id)
genes <- genes[!dup_vec,]
dup_vec <- duplicated(genes$entrezgene_id)
genes <- genes[!dup_vec,]
if(anyNA(genes$entrezgene_id)){
  genes <- genes[-which(is.na(genes$entrezgene_id)),]
}
deseq_frame <- deseq_frame[which(deseq_frame$ensembl_gene_id %in% genes$ensembl_gene_id),]
rownames(deseq_frame) <- deseq_frame$ensembl_gene_id
rownames(genes) <- genes$ensembl_gene_id
combined_frame <- merge(deseq_frame, genes, by=0, all=TRUE)
# genes <- getBM(filters = "ensembl_gene_id",
#                attributes = c("ensembl_gene_id","mgi_symbol"),
#                values = formatted_input,
#                mart = mart)
genes <- genes$entrezgene_id
#if the log operation creates a + or - inf,
#im replacing it with + or - 200
geneList <- (-log(combined_frame$padj, base=10)) * sign(combined_frame$log2FoldChange)
geneList <- setNames(geneList, combined_frame$entrezgene_id)
geneList <- sort(geneList, decreasing = TRUE)
geneList[which(geneList == Inf)] <- 200
geneList[which(geneList == -Inf)] <- -200
genes[which(genes == Inf)] <- 200
genes[which(genes == -Inf)] <- -200

#next block is for preparing wikipathways data
wp.ms.gmt <- read.gmt("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/scripts/enrichment_analysis/wikipathways-20211110-gmt-Mus_musculus.gmt")
wp2gene <- readPathwayGMT("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/scripts/enrichment_analysis/wikipathways-20211110-gmt-Mus_musculus.gmt")
wpid2gene <- wp2gene %>% dplyr::select(wpid,gene)
wpid2name <- wp2gene %>% dplyr::select(wpid,name)
bkgd.genes.entrez <- wp.ms.gmt$gene

#names(geneList) <- combined_frame$entrezgene_id
#genes <- unique(genes)

#paste(outputdir, .filename, sep = "/")

#beginning chapter 15 enrichment analysis
if(all(is.finite(geneList))){
  enriched <- enrichKEGG(genes, organism = "mmu", keyType = "ncbi-geneid", pvalueCutoff = cutoff)
  saveRDS(enriched, file = paste(output_dir,"/",prefix,"_enriched", sep = ""))
  jpeg(filename = paste(output_dir, "/", prefix, ".jpg", sep = ""),
       width = 8, height = 8, units = "in", quality = 100,
       res = 150)
  
  barplot(enriched, showCategory=20)
  dev.off()
  gseenriched <- gseKEGG(geneList, organism = "mmu", keyType = "ncbi-geneid", pvalueCutoff = cutoff, pAdjustMethod = "none")
  saveRDS(gseenriched, file = paste(output_dir,"/",prefix,"_gseenriched", sep = ""))
  
  wiki_enriched <- clusterProfiler::enricher(genes,
    pAdjustMethod = "fdr",
    pvalueCutoff = cutoff,
    TERM2GENE = wpid2gene,
    TERM2NAME = wpid2name)
  saveRDS(wiki_enriched, file = paste(output_dir,"/",prefix,"_wiki_enriched", sep = ""))
}

#to do: enrichKEGG, gseKEGG

#data(geneList)
