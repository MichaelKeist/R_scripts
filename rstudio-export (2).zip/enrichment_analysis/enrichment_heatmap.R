#this gets a set of enrichment results to make a heatmap, doesnt work with enrichR results
library(pheatmap)
library(dichromat)
library(RColorBrewer)

file_vec <- list.files(path = "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/visualizations/enrichment",
           pattern = "_enriched", full.names = TRUE)

#EXTRACTING DATA FROM ENRICHMENT RESULTS
#file <- "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/visualizations/enrichment/did1_NAC_enriched"
#file <- "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/visualizations/enrichment/did2_PFC_enriched"
interesting_paths <- c()

#this loop looks at every enrichment result, and stores the top 5 enriched path for every region
for(file in file_vec){
  working_result <- readRDS(file)
  working_result <- as.data.frame(working_result@result)
  interesting_paths <- c(interesting_paths, working_result$Description[1:5])
}
#many of the top enriched paths were enriched in several regions, so there are several duplicates
dup_vec <- duplicated(interesting_paths)
interesting_paths <- interesting_paths[!dup_vec]


#MAKING HEATMAP INPUT
heatmap_input <- data.frame(Description = interesting_paths)
count <- 1
first <- TRUE
#this loop gets the actual padj values for every pathway of interest for every region/line
for(file in file_vec){
  working_result <- readRDS(file)
  #at some point, get a better col name
  col_name <- basename(file)
  working_result <- as.data.frame(working_result@result)
  working_result <- working_result[,c(2,6)]
  if(any(!(interesting_paths %in% working_result$Description))){
    missing_terms <- interesting_paths[which(!(interesting_paths %in% working_result$Description))]
    missing_rows <- data.frame(Description = missing_terms, p.adjust = rep(1, length(missing_terms)))
    working_result <- rbind(working_result, missing_rows)
  }
  working_result <- working_result[which(working_result$Description %in% interesting_paths),]
  heatmap_input$placehold <- -log(working_result$p.adjust, base = 10)
  colnames(heatmap_input)[length(colnames(heatmap_input))] <- col_name
  # left_out_paths <- interesting_paths[-which(interesting_paths %in% working_result$Description)]
  # left_out_frame <- data.frame(Description = left_out_paths, placehold = rep(1, length(left_out_paths)))
  # heatmap_input <- cbind(heatmap_input, working_result)
}


#BEGINNING HEATMAP PLOT
#formatting input
rownames(heatmap_input) <- heatmap_input$Description
heatmap_input$Description <- NULL

breakList <- seq(0, 4, by=.025)
pheatmap(heatmap_input,
         treeheight_col = 10,
         treeheight_row = 2,
         cluster_rows = F, 
         cluster_cols = T, fontsize_row = 10, show_colnames = T,
         #labels_col =  c("HDID1", "HSNpt"),
         #labels_row = rownames(heatmap_input), angle_col = 0,
         breaks = c(breakList),
         color = colorRampPalette(rev(brewer.pal(n = 7, name = "RdYlBu")))(length(breakList)),
         show_rownames = T,  border_color = F, fontsize_col = 10, main = "-log10(padj) of Pathways")

