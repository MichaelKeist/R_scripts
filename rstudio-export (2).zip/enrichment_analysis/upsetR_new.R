#this script will run upsetR to find the overlaps of enriched pathways between brain regions or the overlaps of DEGs between brain regions
#we already have a script that can run upsetR in the /visualizations/upsetR directory,
#but I think I can make a better one

#install.packages("rlist")
library(rlist)
library(UpSetR)

file_vec <- as.vector(list.files(path = "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/gene_lists/de_genes",
                                 full.names = TRUE))
#the loop reads the file, and adds the DEGs of that file into a list
count <- 1
names <- c()
input_list <- list()
while(count <= length(file_vec)){
  new_genes <- list(readLines(file_vec[count]))
  input_list <- c(input_list, new_genes)
  new_name <- strsplit(file_vec[count], "genes/de_")[[1]][2]
  names(input_list)[count] <- new_name
  names[count] <- new_name
  count <- count + 1
}

#this bit gets the list, turns it into something upsetR can read, and makes the plot
tbl <- fromList(input_list)
jpeg(filename = "/stor/home/mk37825/all_regions_upsetR_more_intercepts.jpg", 
     width = 12, height = 12, units = "in", quality = 100, 
     res = 150)
upset(tbl, order.by = "freq",nsets = 100, text.scale = 1.4, nintersects = 80)
dev.off()

