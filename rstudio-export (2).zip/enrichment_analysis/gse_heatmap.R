#this script reads in a list of gse results and makes a heatmap based on enrichment score
#this gets a set of enrichment results to make a heatmap, doesnt work with enrichR results
library(pheatmap)
library(dichromat)
library(RColorBrewer)

file_vec <- list.files(path = "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/visualizations/enrichment/no_cutoff_all_genes",
                       pattern = "_gseenriched", full.names = TRUE)

#EXTRACTING DATA FROM ENRICHMENT RESULTS
#file <- "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/visualizations/enrichment/did1_NAC_enriched"
#file <- "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/visualizations/enrichment/did2_PFC_enriched"
interesting_paths <- c()

#this loop looks at every enrichment result, and stores the top 5 enriched path for every region
for(file in file_vec){
  working_result <- readRDS(file)
  working_result <- as.data.frame(working_result@result)
  interesting_paths <- c(interesting_paths, working_result$Description[1:5])
}
#many of the top enriched paths were enriched in several regions, so there are several duplicates
dup_vec <- duplicated(interesting_paths)
interesting_paths <- interesting_paths[!dup_vec]


#MAKING HEATMAP INPUT
heatmap_input <- data.frame(Description = interesting_paths[order(interesting_paths)])
rownames(heatmap_input) <- heatmap_input$Description
count <- 1
#this loop gets the actual padj values for every pathway of interest for every region/line
for(file in file_vec){
  working_result <- readRDS(file)
  #at some point, get a better col name
  col_name <- basename(file)
  working_result <- as.data.frame(working_result@result)
  working_result <- working_result[,c(2,4)]
  if(any(!(interesting_paths %in% working_result$Description))){
######## IF A PATHWAY IN INTERESTING_PATHS DOESN'T HAVE AN ENRICHMENT SCORE FOR A SAMPLE GROUP, ASSIGN SCORE OF 0
    missing_terms <- interesting_paths[which(!(interesting_paths %in% working_result$Description))]
    missing_rows <- data.frame(Description = missing_terms, enrichmentScore = rep(0, length(missing_terms)))
    working_result <- rbind(working_result, missing_rows)
  }
  working_result <- working_result[order(working_result$Description),]
  rownames(working_result) <- working_result$Description
  working_result <- working_result[which(working_result$Description %in% interesting_paths),]
  heatmap_input$enrichment_score <- working_result$enrichmentScore
  colnames(heatmap_input)[length(colnames(heatmap_input))] <- col_name
  # left_out_paths <- interesting_paths[-which(interesting_paths %in% working_result$Description)]
  # left_out_frame <- data.frame(Description = left_out_paths, placehold = rep(1, length(left_out_paths)))
  # heatmap_input <- cbind(heatmap_input, working_result)
}
########TODO: FIX THE DID2PFC/DID2VTA WEIRDNESS (ISSUE STEMS FROM ACTUAL GSEA RESULTS)
########THE PFC TEST RE-RAN AND GOT SAME RESULTS, NOW TRY WITH DID2VTA!!!
########THIS ISSUE IS STILL UNRESOLVED, FIX BEFORE USING GSEA RESULTS

#BEGINNING HEATMAP PLOT
#formatting input
rownames(heatmap_input) <- heatmap_input$Description
heatmap_input$Description <- NULL

breakList <- seq(-1, 1, by=.025)
pheatmap(heatmap_input,
         treeheight_col = 10,
         treeheight_row = 2,
         cluster_rows = T, 
         cluster_cols = T, fontsize_row = 10, show_colnames = T,
         #labels_col =  c("HDID1", "HSNpt"),
         #labels_row = rownames(heatmap_input), angle_col = 0,
         breaks = c(breakList),
         color = colorRampPalette(rev(brewer.pal(n = 7, name = "RdYlBu")))(length(breakList)),
         show_rownames = T,  border_color = F, fontsize_col = 10, main = "Enrichment Scores of Pathways")

