#messing around with the cytoscape tool
library(RCy3)
cytoscapePing()
#didnt work!