#import evreything
library(DESeq2)
library(readr)
library(dplyr)
library(ggplot2)
library(ggrepel)

setwd('/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/')
annot <-read.csv("annot_table.csv",header=TRUE)
rownames(annot) <- annot$X
annot <- select(annot, -1)
#get sample table
counts <- read.csv("countsframe.csv", header = T)
row.names(counts) <- counts$X
counts <- select(counts, -1)


#subset for DE Genes (DID1)
de_gene_results1 <- read.csv('../DESeq/probablynotusefulanymore/did1_filtered_no_l2fc_extra_annot.csv', header = T)
de_genes_vec_1 <- as.vector(de_gene_results1$ensembl_gene_id_version)
de_counts_1 <- counts[de_genes_vec_1,]
#for DID2
de_gene_results2 <- read.csv('../DESeq/probablynotusefulanymore/did2_filtered_no_l2fc_extra_annot.csv', header = T)
de_genes_vec_2 <- as.vector(de_gene_results2$ensembl_gene_id_version)
de_counts_2 <- counts[de_genes_vec_2,]



#function to create log dds Matrix
rlMatrixMaker <- function(counts, annot, subsetOut = 'DID1') {
  #subset the matrices
  smallannot <- subset(annot, !grepl(subsetOut, mouseline))
  smallcounts <- t(counts)
  smallcounts <- subset(smallcounts, !grepl(subsetOut, annot$mouseline))
  smallcounts <- t(smallcounts)
  
  #CREATE DDSEQ MATRIX (HSNP vs DID2)
  my.design <- smallannot
  mouseline <- factor(my.design$mouseline,levels=c("DID1", "DID2", "HSNp"))
  sex <- factor(my.design$sex, levels=c('F', 'M'))
  brain_region <- factor(my.design$brain_region, levels =c('CEA', 'BLA'))
  ddsMatrix <- DESeqDataSetFromMatrix(countData = smallcounts, colData = my.design, design = ~ mouseline + sex + brain_region)
  
  
  ## Remove genes with no counts across samples
  dds_no_zero <- ddsMatrix[rowSums(counts(ddsMatrix)) > 0,] 
  rl_dds_no_zero <- rlog(dds_no_zero, blind=FALSE)
  return(rl_dds_no_zero)
  
}

##FOR All Genes
rl_ddsMatrixall <- rlMatrixMaker(counts, annot, 'XXXXX')
rl_ddsMatrixdid1 <- rlMatrixMaker(counts, annot, 'DID2')
rl_ddsMatrixdid2 <- rlMatrixMaker(counts, annot, 'DID1')


#FOR DE Genes
rlde_ddsMatrixdid1 <- rlMatrixMaker(de_counts_1, annot, 'DID2')
rlde_ddsMatrixdid2 <- rlMatrixMaker(de_counts_2, annot, 'DID1')


#Generate PCA
z <- DESeq2::plotPCA(rl_ddsMatrixdid2, intgroup=c("mouseline", "brain_region"))
z
z + geom_text_repel(aes(label=name), box.padding = .5) 

#save counts deseq all in counts folder
assay <- assay(rl_ddsMatrixall)
write.csv(assay, file = 'all_ddscounts.csv', row.names = T, quote = F)

#Add shapes to PCA

pcaData<- plotPCA(rl_ddsMatrixdid2, intgroup=c("mouseline","brain_region"),returnData = TRUE)
pcaData
percentVar <- round(100 * attr(pcaData, "percentVar"))


ploted<-ggplot(pcaData, aes(x = PC1, y = PC2, color = factor(brain_region), shape = factor(brain_region))) + 
  geom_point(size =3, aes(fill=factor(mouseline))) + 
  geom_point(size =3) + 
  scale_shape_manual(values=c(21,22)) + 
  scale_alpha_manual(values=c("F"=0, "M"=1)) + 
  xlab(paste0("PC1: ", percentVar[1], "% variance")) + 
  ylab(paste0("PC2: ", percentVar[2], "% variance")) + 
  ggtitle("PCA of all genes, no covariate adjusted")
ploted