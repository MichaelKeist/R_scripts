#this script will get counts frames from all 6 brain regions, and combines them into one frame
#actually, bla and cea were mapped to ensembl ids, while others were mapped to gene names :/
library(matrixStats)
library(dplyr)
library(tidyverse)
library(pheatmap)
library(RColorBrewer)

make_sex_vec <- function(input){
  sex_vec <- c()
  for(sample in input){
    if(grepl("M", sample)){
      sex_vec <- c(sex_vec, "Male")
    }else{
      sex_vec <- c(sex_vec, "Female")
    }
  }
  return(sex_vec)
}
make_line_vec <- function(input){
  region_vec <- c()
  line_vec <- c()
  for(sample in input){
    if(grepl("DID1", sample)){
      line_vec <- c(line_vec, "DID1")
    }else if(grepl("DID2", sample)){
      line_vec <- c(line_vec, "DID2")
    }else{
      line_vec <- c(line_vec, "HSNPT")
    }
  }
  return(line_vec)
}

#loading data
bla_cea_frame <- read.table(file = "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/BLA_CEA_tables/all_ddsnormalized.csv",
                            header = TRUE, sep = ",")
bnst_frame <- read.table(file = "/stor/scratch/WCAAR/eke_scratch/Angela/DESeq_by_tissue/BNST/2020-11-25-normalizedcounts.csv",
                         header = TRUE, sep = ",")
nac_frame <- read.table(file = "/stor/scratch/WCAAR/eke_scratch/Angela/DESeq_by_tissue/NAC/2020-12-01-normalizedcounts-NAC.csv",
                        header = TRUE, sep = ",")
pfc_frame <- read.table(file = "/stor/scratch/WCAAR/eke_scratch/Angela/DESeq_by_tissue/PFC/2020-12-01-normalizedcounts-PFC.csv",
                        header = TRUE, sep = ",")
vta_frame <- read.table(file = "/stor/scratch/WCAAR/eke_scratch/Angela/DESeq_by_tissue/VTA/2020-12-06-normalizedcounts-VTA.csv",
                        header = TRUE, sep = ",")


all_tables <- list(bla_cea_frame,bnst_frame, nac_frame, pfc_frame, vta_frame)

#log2 normalizing counts
for(i in 1:length(all_tables)){
  rownames(all_tables[[i]]) <- all_tables[[i]]$X
  all_tables[[i]]$X <- NULL
  all_tables[[i]] <- log2(all_tables[[i]])
  all_tables[[i]]$X <- rownames(all_tables[[i]])
  all_tables[[i]] <- all_tables[[i]][,c(length(colnames(all_tables[[i]])), 1:(length(colnames(all_tables[[i]])) - 1))]
  all_tables[[i]][all_tables[[i]] == -Inf] <- -5
}

#top 5% variance genes are selected
count = 1
selected_genes <- c()
while(count <= length(all_tables)){
  all_tables[[count]]$variance <- rowVars(as.matrix(all_tables[[count]][,c(-1)]))
  all_tables[[count]] <- arrange(all_tables[[count]], desc(variance))
  set_genes <- all_tables[[count]][1:(length(rownames(all_tables[[count]])) %/% 20),]
  set_genes <- as.vector(set_genes$X)
  selected_genes <- c(selected_genes, set_genes)
  count <- count + 1
}

#removing duplicates in the interesting gene set, getting only genes measured in every region
dup_subset <- duplicated(selected_genes)
narrow_genes <- selected_genes[!dup_subset]
for(frame in all_tables){
  narrow_genes <- narrow_genes[which(narrow_genes %in% frame$X)]
}

#getting interesting genes from each frame
count = 1
while(count <= length(all_tables)){
  all_tables[[count]]$variance <- NULL
  all_tables[[count]] <- all_tables[[count]][(which(all_tables[[count]]$X %in% narrow_genes)),]
  all_tables[[count]]$X <- as.character(all_tables[[count]]$X)
  rownames(all_tables[[count]]) <- all_tables[[count]]$X
  all_tables[[count]]$X <- NULL
  count <- count + 1
}

#deprecated section, populates unmeasured genes with zeros
#THIS COMMENTED BIT COULD BE HELPFUL IN OTHER SCRIPTS
# count = 1
# while(count <= length(all_tables)){
#   all_tables[[count]]$variance <- NULL
#   all_tables[[count]] <- all_tables[[count]][(which(all_tables[[count]]$X %in% narrow_genes)),]
#   all_tables[[count]]$X <- as.character(all_tables[[count]]$X)
#   for(gene in narrow_genes[-c(which(narrow_genes %in% all_tables[[count]]$X))]){
#     new_row <- as.list(c(gene, rep(0, length(colnames(all_tables[[count]])) - 1)))
#     new_row_df <- data.frame(new_row)
#     colnames(new_row_df) <- colnames(all_tables[[count]])
#     all_tables[[count]] <- rbind(all_tables[[count]],new_row_df)
#     all_tables[[count]]$X[length(all_tables[[count]]$X)] <- gene
#   }
#   rownames(all_tables[[count]]) <- all_tables[[count]]$X
#   all_tables[[count]]$X <- NULL
#   count <- count + 1
# }

#making annot
bla_cea_samples <- colnames(bla_cea_frame)[2:length(colnames(bla_cea_frame))]
bla_cea_region_vec <- c()
for(sample in bla_cea_samples){
  if(grepl("4_", sample)){
    bla_cea_region_vec <- c(bla_cea_region_vec, "bla")
  }else{
    bla_cea_region_vec <- c(bla_cea_region_vec, "cea")
  }
}
bla_cea_sex_vec <- make_sex_vec(bla_cea_samples)
bla_cea_line_vec <- make_line_vec(bla_cea_samples)
bla_cea_annot <- data.frame(brain_region = bla_cea_region_vec, line = bla_cea_line_vec, sex = bla_cea_sex_vec)
rownames(bla_cea_annot) <- colnames(bla_cea_frame)[2:length(colnames(bla_cea_frame))]

bnst_annot <- data.frame(brain_region = rep("  bnst", length(colnames(bnst_frame)) - 1))
bnst_annot$sex <- make_sex_vec(colnames(bnst_frame)[2:length(colnames(bnst_frame))])
bnst_annot$line <- make_line_vec(colnames(bnst_frame)[2:length(colnames(bnst_frame))])
rownames(bnst_annot) <- colnames(bnst_frame)[2:length(colnames(bnst_frame))]

nac_annot <- data.frame(brain_region = rep("  nac", length(colnames(nac_frame)) - 1))
nac_annot$sex <- make_sex_vec(colnames(nac_frame)[2:length(colnames(nac_frame))])
nac_annot$line <- make_line_vec(colnames(nac_frame)[2:length(colnames(nac_frame))])
rownames(nac_annot) <- colnames(nac_frame)[2:length(colnames(nac_frame))]

pfc_annot <- data.frame(brain_region = rep("  pfc", length(colnames(pfc_frame)) - 1))
pfc_annot$sex <- make_sex_vec(colnames(pfc_frame)[2:length(colnames(pfc_frame))])
pfc_annot$line <- make_line_vec(colnames(pfc_frame)[2:length(colnames(pfc_frame))])
rownames(pfc_annot) <- colnames(pfc_frame)[2:length(colnames(pfc_frame))]

vta_annot <- data.frame(brain_region = rep("  vta", length(colnames(vta_frame)) - 1))
vta_annot$sex <- make_sex_vec(colnames(vta_frame)[2:length(colnames(vta_frame))])
vta_annot$line <- make_line_vec(colnames(vta_frame)[2:length(colnames(vta_frame))])
rownames(vta_annot) <- colnames(vta_frame)[2:length(colnames(vta_frame))]

annot_frame <- rbind(bla_cea_annot, bnst_annot, nac_annot, pfc_annot, vta_annot)
###CHOOSING WHICH VARIABLE TO LOOK AT
#annot_frame$line <- NULL
#annot_frame$brain_region <- NULL

combined_hv_frame <- cbind(all_tables[[1]], all_tables[[2]], all_tables[[3]], all_tables[[4]], all_tables[[5]])
combined_hv_frame <- sapply(combined_hv_frame, as.numeric )
rownames(combined_hv_frame) <- rownames(all_tables[[1]])
scale_rows = function(x){
  m = apply(x, 1, mean, na.rm = T)
  s = apply(x, 1, sd, na.rm = T)
  if(s == 0){
    s = 0.01
  }
  return((x - m) / s)
}
#combined_hv_frame <- scale_rows(combined_hv_frame)
combined_hv_frame[is.na(combined_hv_frame)] <- 0
anyNA(combined_hv_frame)
#TRY WITH LOG TRANSFORMED DATA, LESS GENES, Z-SCORES
#breaks for unscaled = -5,5    breaks for scaled = -2,2
breakList <- seq(-5, 5, by=.05)
par(oma = c(5,5,5,5))
pheatmap(combined_hv_frame,
         treeheight_col = 3,
         treeheight_row = 1,
         cluster_rows = T, 
         cluster_cols = T,
         fontsize_row = 4, show_colnames = F,
         breaks = c(breakList),
         color = colorRampPalette(rev(brewer.pal(n = 7, name = "RdYlBu")))(length(breakList)),
         show_rownames = F,  border_color = F, main = "Log2 Normalized Counts Heatmap",
         fontsize_col = 1,
         annotation_col = annot_frame, cex = .9)
print("test")
#, scale = "row"
#RdYlBu
#pheatmap(combined_hv_frame)