#!/bin/bash
INPUT_LOC=$"/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value/"
OUTPUT_LOC=$"/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/gene_lists/upreg_downreg_ei"
for FILE in $INPUT_LOC*
do
	SIMPLE_NAME=${FILE##*/}
	SIMPLE_NAME=${SIMPLE_NAME%.*}
	SIMPLE_NAME=${SIMPLE_NAME%_*}
	echo "Rscript /stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/scripts/DESeq_scripts/upreg_downreg_finder.R -i $FILE -o $OUTPUT_LOC -s $SIMPLE_NAME -e FALSE, -c TRUE" >> upreg_downreg_coms
done
