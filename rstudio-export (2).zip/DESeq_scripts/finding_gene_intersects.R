setwd("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/gene_lists")
# did1_de_genes <- as.data.frame(fread("did1_genes_no_outlier", header = FALSE))$V1
# did2_de_genes <- as.data.frame(fread("did2_genes_no_outlier", header = FALSE))$V1
# shared_genes <- intersect(did1_de_genes,did2_de_genes)
# did1_uniq <- did1_de_genes[!(did1_de_genes %in% shared_genes)]
# did2_uniq <- did2_de_genes[!(did2_de_genes %in% shared_genes)]
black_module <- as.data.frame(fread("black_genevec", header = FALSE))$V1
green_module <- as.data.frame(fread("red_genevec", header = FALSE))$V1
red_module <- as.data.frame(fread("green_genevec", header = FALSE))$V1
did1_bla <- scan("did1_BLA_genes", character(), quote = "")
did1_bla_black <- intersect(did1_bla, black_module)
did2_bla <- scan("did2_BLA_genes", character(), quote = "")
did2_bla_black <- intersect(did2_bla, black_module)
did1_bla_red <- intersect(did1_bla, red_module)
did2_bla_red <- intersect(did2_bla, red_module)
did1_bla_green <- intersect(did1_bla, green_module)
did2_bla_green <- intersect(did2_bla, green_module)

#there's a lot of gene vectors here, but i dont want to delete them since most are still useful
did1_bla_25 <- scan("~/did1_bla_symbols", character(), quote="")
did1_cea_25 <- scan("~/did1_cea_symbols", character(), quote="")
did2_bla_25 <- scan("~/did2_bla_symbols", character(), quote="")
did2_cea_25 <- scan("~/did2_cea_symbols", character(), quote="")

### RUNNING ENRICHR ON SELECTED GENES
dbs <- listEnrichrDbs()
dbs <- c("KEGG_2019_Mouse", "Mouse_Gene_Atlas", "WikiPathways_2019_Mouse")
genes <- did2_bla_green
enriched <- enrichr(genes, dbs)
plotEnrich(enriched[[1]], showTerms = 10, orderBy = "Combined.Score")

z <- as.data.frame(enriched[[1]])
