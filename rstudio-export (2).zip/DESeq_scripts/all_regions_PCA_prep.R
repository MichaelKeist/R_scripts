count <- as.data.frame(fread("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/all_brain_regions_tables/counts.csv"))
annot <- as.data.frame(fread("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/all_brain_regions_tables/annot.csv"))
rownames(count) <- count$V1
count$V1 <- NULL
annot <- t(annot)
colnames(annot) <- annot[1,]
annot <- annot[-1,]
annot <- as.data.frame(annot)
rownames(annot) <- annot$V1
annot$V1 <- NULL

i <- 1
row_vec <- c()
while(i <= 15377){
  row_vec <- c(row_vec, i)
  i <- i + 1
}
rownames(count) <- row_vec
count_rows <- rownames(count)
which(count_dup == TRUE)
anyDuplicated(colnames(count))
any(duplicated(count_rows))

write_tsv(annot, "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/all_brain_regions_tables/annot_PCA.tsv")
write_tsv(count, "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/all_brain_regions_tables/counts_PCA.tsv")
