# Load WGCNA and flashClust libraries every time you open R
library(WGCNA)
library(flashClust)
library(dplyr)

#create normalized counts table

setwd('/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/')
annot <-read.csv("annot_table.csv",header=TRUE)
rownames(annot) <- annot$X
annot$X <- NULL
#get sample table
counts <- read.csv("countsframe.csv", header = T)
row.names(counts) <- counts$X
counts$X <- NULL

#design
my.design <- annot
mouseline <- factor(my.design$mouseline,levels=c("DID1", "DID2", "HSNp"))
sex <- factor(my.design$sex, levels=c('F', 'M'))
brain_region <- factor(my.design$brain_region, levels =c('CEA', 'BLA'))
ddsMatrix <- DESeqDataSetFromMatrix(countData = counts, colData = my.design, design = ~ mouseline + sex + brain_region)

#preliminary filtration
dds1 <- ddsMatrix[rowSums(counts(ddsMatrix)) > 50,] 
dim(dds1) 


#ensemble import
library(biomaRt)
library(dplyr)
ensembl = useMart("ENSEMBL_MART_ENSEMBL", dataset="mmusculus_gene_ensembl", host="www.ensembl.org")
annot<-getBM(c("ensembl_gene_id_version","ensembl_gene_id", "mgi_symbol","description", "chromosome_name", "strand", "start_position", "end_position","gene_biotype"),values= rownames(dds1), mart=ensembl)


#normalize counts
dds1 <- estimateSizeFactors(dds1)
normalized.counts <- as.data.frame(counts(dds1, normalized=T))
#row name fixing
rownames <- as.vector(rownames(normalized.counts))
write_lines(rownames, 'rownames.txt')
#cut dots off other one
fixedrownames <- read_lines('fixedrownames2.txt')

rownames(normalized.counts) <- fixedrownames

idx_counts <- match(rownames(normalized.counts),annot$ensembl_gene_id)
normalized.counts_genes <- data.frame(cbind(normalized.counts, annot[idx_counts,]))

normcountsunique <- normalized.counts_genes[!duplicated(normalized.counts_genes$mgi_symbol), ]
normcountsunique <- normcountsunique[!with(normcountsunique, is.na(normcountsunique$mgi_symbol)),]
rownames(normcountsunique) <- normcountsunique$mgi_symbol
normcountsunique_genes <- normcountsunique[,1:58]
colnames(normcountsunique_genes)

match(colnames(normalized.counts), colnames(normcountsunique_genes))

write.csv(normcountsunique_genes, 'all_ddsnormalized.csv')




