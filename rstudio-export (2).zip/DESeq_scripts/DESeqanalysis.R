library(tximport)
library(readr)
library("DESeq2")
library(data.table)
library(dplyr)

#brain region and mouse line of interest
specified_region <- "CEA"
mouse_line <- "DID1" #the indicated mouse line is the one you are NOT looking at

#change to include your counts matrix file
counts <- fread("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/BLA_CEA_tables/countsframe.csv", header = T)
counts <- as.data.frame(counts)
row.names(counts) <- counts$V1
counts <- counts[,2:59]
annot <- fread("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/BLA_CEA_tables/annot_table.csv", header = T)
annot <- as.data.frame(annot)
rownames(annot) <- annot$V1
annot <- subset(annot, select = -c(1,3,4))
#removing outlier identified by PCA
annot <- annot[!(row.names(annot) %in% c("HSNpMBL105_S60")),]
counts <- subset(counts, select = -c(50))
annot <- as.data.frame(annot)

#SUBSETTING ANNOT
smallannot <- subset(annot, grepl(specified_region, brain_region))
smallannot <- subset(smallannot, !grepl(mouse_line, mouseline))

#SUBSETTING COUNTS
smallcounts <- counts[,which(colnames(counts) %in% rownames(smallannot))]
smallcounts <- smallcounts[rowSums(smallcounts) > 50,]

#samplenames for counts- change to include the names of your samples in the order they appear in your counts matrix
#change according to how many samples you have
lib <- rownames(smallannot)

#change to include your conditions
my.design <- smallannot
conds <- factor(my.design$mouseline,levels=c("HSNp", mouse_line))
#my.design
ddsMatrix <- DESeqDataSetFromMatrix(countData = smallcounts, colData = my.design, design = ~ mouseline)
library("BiocParallel")
register(MulticoreParam(8))


#estimate size factors, dispersion, normalize and perform negative binomial test to compare across conditions
dds<-DESeq(ddsMatrix)

#collect results from the statistical testing, order by adjusted pvalue and write into an output file
res<-results(dds)
resOrdered <- res[order(res$padj),]
summary(res)
resframe <- as.data.frame(resOrdered)
deg_frame <- resframe[which(resframe$padj < 0.05),]

write.csv(resframe,
file = "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value/did2_CEA_output.csv")

#change to desired output file name
#write.csv(resframe, "~/RRHO_test/did1_bla.csv")

#change to desired output file name
#jpeg('/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/did1_vs_did1_CEA_maplot.jpg')
#plotMA(dds,ylim=c(-2,2),main="DESeq2")

#dev.off()
