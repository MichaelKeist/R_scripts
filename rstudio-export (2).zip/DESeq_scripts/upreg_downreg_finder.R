#This script reads in DESeq outputs, and creates lists of the
#up-regulated and down-regulated genes
#install.packages("getopt")
#install.packages("readr")
library('getopt')

spec = matrix(c(
  'input_csv', 'i', 1, 'character',
  'output_loc', 'o', 1, 'character',
  'alpha', 'a', 2, 'double',
  'l2fc_cutoff', 'l', 2, 'double',
  'extra_info', 'e', 2, 'logical',
  'suffix', 's', 2, 'character',
  'cat', 'c', 2, 'logical'
), byrow=TRUE, ncol=4)

opt = getopt(spec)
if(is.null(opt$alpha)){
  alpha <- .05
}else{
  alpha = opt$alpha
}
if(is.null(opt$l2fc_cutoff)){
  l2fc_cutoff <- 0
}else{
  l2fc_cutoff = abs(opt$l2fc_cutoff)
}
if(is.null(opt$extra_info)){
  extra_info <- FALSE
}else{
  extra_info <- opt$extra_info
}
if(is.null(opt$cat)){
	cat <- FALSE
}else{
	cat <- opt$cat
}

suffix <- opt$suffix

input = opt$input_csv
input_frame <- read.table(input, header = TRUE, sep=",")

#make function to make boolean vector marking rows that contain NAs
na_finder <- function(row){
  na_bool <- c()
  if(anyNA(row)){
    na_bool <- c(na_bool, FALSE)
  }else{
    na_bool <- c(na_bool, TRUE)
  }
  return(na_bool)
}

#subset input frame to remove NA rows
na_subset <- apply(input_frame, MARGIN=1, FUN=na_finder)
input_frame <- input_frame[which(na_subset),]

#subset to get all significant genes
significance_bool <- input_frame$padj < alpha
input_frame <- input_frame[which(significance_bool),]

setwd(opt$output_loc)
if(TRUE){
	if(cat){
		de_genes <- as.character(input_frame[,1])
  	write(de_genes, file = paste(opt$output_loc,"/de_",suffix, sep = ""))
	}else{
  	upreg_genes <- as.character(input_frame[which(input_frame$log2FoldChange > l2fc_cutoff),1])
  	downreg_genes <- as.character(input_frame[which(input_frame$log2FoldChange < -l2fc_cutoff),1])
  	write(upreg_genes, file = paste(opt$output_loc,"/upreg_",suffix, sep = ""))
  	write(downreg_genes, file = paste(opt$output_loc,"/downreg_",suffix, sep = ""))
	}
}
# if(extra_info){
#   upreg_genes <- input_frame[which(input_frame$log2FoldChange > l2fc_cutoff),]
#   downreg_genes <- input_frame[which(input_frame$log2FoldChange < -l2fc_cutoff),]
#   write.csv(upreg_genes, file = paste(opt$output_loc,"/upreg_",suffix, sep = ""), row.names = FALSE)
#   write.csv(downreg_genes, file = paste(opt$output_loc,"/downreg_",suffix, sep = ""), row.names = FALSE)
# }
