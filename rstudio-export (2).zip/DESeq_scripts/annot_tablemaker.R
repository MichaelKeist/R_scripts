#makes annotation table with sample name, mouseline, sex, brain region, ERCC status
library(dplyr)
annot_table <- read.table('samplenames_copy', header = T)

#set other variables
annot_table$mouseline <- substring(annot_table$Sample, 1, 4)
annot_table$sex <- substring(annot_table$Sample, 5, 5)

#set row names to first column
rownames(annot_table) <- annot_table[,1]
annot_table <- annot_table[-c(1)]

annot_table$ERCC <- 'No'
#add ERCC column
mix1list <- c('DID1FBL124_S3', 'DID1MBL204_S10', 'DID2MBL274_S14', 'DID2FBL254_S19', 'HSNpMBL74_S24', 'HSNpMBL104_S30', 'DID1MBL165_S32', 'DID2MBL305_S50', 'HSNpFBL15_S51', 'HSNpMBL75_S54')
mix2list <- c('DID1FBL114_S1', 'DID1MBL184_S6', 'DID2MBL264_S12', 'DID2FBL244_S17', 'HSNpMBL64_S22', 'HSNpFBL44_S27', 'DID1FBL145_S37', 'DID1MBL205_S40', 'DID2FBL225_S43', 'DID2MBL285_S46', 'HSNpFBL35_S55', 'HSNpMBL95_S58')

#create mix1filter table
annot_table[mix1list, 3] <- 'Mix1'
annot_table[mix2list, 3] <- 'Mix2'

#add brain regions

#slicer
CEAtable <- annot_table %>%
  filter(row_number() %% 2 == 1, row_number() < 30)


CEA_flip_table <- annot_table %>%
  filter(row_number() %% 2 != 1, row_number() >= 30)
#CEAtable$brain_region <- 'CEA'

BLAtable <- annot_table %>%
  filter(row_number() %% 2 != 1, row_number() < 30)


BLA_flip_table <- annot_table %>%
  filter(row_number() %% 2 == 1, row_number() >= 30)

#BLAtable$brain_region <- 'BLA'

annot_table$brain_region <- 'F'
annot_table[rownames(CEAtable), 4] <- 'CEA'
annot_table[rownames(CEA_flip_table), 4] <- 'CEA'
annot_table[rownames(BLAtable), 4] <- 'BLA'
annot_table[rownames(BLA_flip_table), 4] <- 'BLA'

annot_table[1, 4] <- 'BLA'
annot_table[29, 4] <- 'BLA'


#write file to matrix
write.csv(annot_table, 'annot_table.csv', row.names = T)