library(biomaRt)
stats <- fread("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/currentlyuseful/did2_CEA_no_outlier.csv", header = T)
statsfiltered <- as.data.frame(stats)
statsfiltered <- statsfiltered %>%
  #filter(abs(log2FoldChange) > 1.2) %>%
  filter(baseMean > 1) %>%
  filter(padj < .05)

rownames(statsfiltered) <- statsfiltered$V1
statsfiltered <- statsfiltered[,2:7]

### REMOVING OUTLIER (MAYBE NOT NEEDED ANYMORE?)
#did1nooutlier <- did1res[2:56261,]
#rownames(did1nooutlier) <- did1nooutlier$V1
#did1nooutlier <- select(did1nooutlier, -1)

write.csv(statsfiltered, "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/currentlyuseful/did1_vs_did2_CEA_DE.csv", quote = FALSE)

### GENES WITH NO DOTS

write_lines(rownames(statsfiltered), "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value/temp")
geneswithnodots <- read_lines("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value/did2_CEA_genes_no_outlier")
statsfiltered$gene_id <- geneswithnodots



### ADDING EXTRA ANNOTATION INFORMATION
ensembl = useMart("ENSEMBL_MART_ENSEMBL", dataset="mmusculus_gene_ensembl", host="www.ensembl.org")
annot<-getBM(c("ensembl_gene_id_version","ensembl_gene_id", "mgi_symbol","description", "chromosome_name", "strand", "start_position", "end_position","gene_biotype"),values= statsfiltered$gene_id, mart=ensembl)
matchedannot <- match(statsfiltered$gene_id,annot$ensembl_gene_id)
did1_bla_de_extra_annot <- data.frame(cbind(statsfiltered, annot[matchedannot,]))


did1_bla_de_extra_annot$rownames <- rownames(did1_bla_de_extra_annot)
#write_csv(did1_bla_de_extra_annot, "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/currentlyuseful/did1_vs_did2_CEA_DE.csv")
write_lines(did1_bla_de_extra_annot$mgi_symbol, "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value/did2_CEA_genes_no_outlier")

zzz <- fread("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/currentlyuseful/did2_CEA_DE.csv")
#write_lines(rownames(did1filtered), "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/ensemblgenenames")
