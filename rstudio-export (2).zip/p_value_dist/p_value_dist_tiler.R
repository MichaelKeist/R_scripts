#Example pvalue distribution R script (input is deseq2 csv file)
library(ggplot2)
library(reshape2)
library(jpeg)
library(graphics)
library(gridExtra)
file_vec <- list.files(path = "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value",
                       full.names = TRUE)
#this next section rearranges the groups to present bla and cea adjacent to eachother
x <- file_vec[2]
file_vec[2] <- file_vec[3]
file_vec[3] <- x
x <- file_vec[8]
file_vec[8] <- file_vec[9]
file_vec[9] <- x
#jpeg(filename = "~/p_value_dist_tiles.jpg", 
    #width = 8, height = 8, units = "in", quality = 100, 
    #res = 150)
data_list <- list()
simple_names <- c()
count = 1
while(count <= length(file_vec)){
  file = file_vec[count]
  deout<-read.table(file, header=TRUE, sep=",", row.names=1)
  deout<-na.omit(deout)
  deout_sub<-deout[,c("pvalue","padj")]
  data<- melt(deout_sub)
  data_list[[count]] <- data
  simple_name <- strsplit(file, "/")
  simple_name <- simple_name[[1]]
  simple_name <- simple_name[length(simple_name)]
  simple_name <- strsplit(simple_name, "\\.")[[1]][1]
  #simple_name <- paste(strsplit(simple_name, "_")[[1]][1], strsplit(simple_name, "_")[[1]][2], "pdist.pdf", sep = "_")
  simple_name <- paste(strsplit(simple_name, "_")[[1]][1], strsplit(simple_name, "_")[[1]][2], sep = " ")
  simple_names <- c(simple_names, simple_name)
  #file_loc <- paste("~/p_value_dist/", simple_name, sep="")
  #pdf(file_loc)
  #jpeg(filename = paste("~/p_value_dist/", simple_name, sep=""), 
       #width = 8, height = 8, units = "in", quality = 100, 
       #res = 150)
  #ggplot(data,aes(x=value, fill=variable)) + geom_density(alpha=0.25)
  #ggplot(data,aes(x=value, fill=variable)) + geom_histogram(alpha=0.25)
  count = count + 1
  
}
#dev.off()

# for(i in seq(1,12)){
#   cat("ggplot(data_list[[",i,"]]",",aes(x=value, fill=variable)) + geom_density(alpha=0.25) + ggtitle(\"",simple_names[i],"\"),")
# }

jpeg(filename = "~/p_value_dist_tiles.jpg", 
width = 36, height = 12, units = "in", quality = 100, 
res = 150)
grid.arrange(ggplot(data_list[[ 1 ]] ,aes(x=value, fill=variable)) + geom_density(alpha=0.25) + ggtitle(" did1 BLA ") + theme(legend.position = "none") + theme(plot.title = element_text(size = 24)) + theme(axis.text=element_text(size=15)) + theme(axis.title=element_text(size=20)),
             ggplot(data_list[[ 2 ]] ,aes(x=value, fill=variable)) + geom_density(alpha=0.25) + ggtitle(" did1 CEA ") + theme(legend.position = "none") + theme(plot.title = element_text(size = 24)) + theme(axis.text=element_text(size=15)) + theme(axis.title=element_text(size=20)),
             ggplot(data_list[[ 3 ]] ,aes(x=value, fill=variable)) + geom_density(alpha=0.25) + ggtitle(" did1 BNST ") + theme(legend.position = "none") + theme(plot.title = element_text(size = 24)) + theme(axis.text=element_text(size=15)) + theme(axis.title=element_text(size=20)),
             ggplot(data_list[[ 4 ]] ,aes(x=value, fill=variable)) + geom_density(alpha=0.25) + ggtitle(" did1 NAC ") + theme(legend.position = "none") + theme(plot.title = element_text(size = 24)) + theme(axis.text=element_text(size=15)) + theme(axis.title=element_text(size=20)),
             ggplot(data_list[[ 5 ]] ,aes(x=value, fill=variable)) + geom_density(alpha=0.25) + ggtitle(" did1 PFC ") + theme(legend.position = "none") + theme(plot.title = element_text(size = 24)) + theme(axis.text=element_text(size=15)) + theme(axis.title=element_text(size=20)),
             ggplot(data_list[[ 6 ]] ,aes(x=value, fill=variable)) + geom_density(alpha=0.25) + ggtitle(" did1 VTA ") + theme(legend.position = "none") + theme(plot.title = element_text(size = 24)) + theme(axis.text=element_text(size=15)) + theme(axis.title=element_text(size=20)),
             ggplot(data_list[[ 7 ]] ,aes(x=value, fill=variable)) + geom_density(alpha=0.25) + ggtitle(" did2 BLA ") + theme(legend.position = "none") + theme(plot.title = element_text(size = 24)) + theme(axis.text=element_text(size=15)) + theme(axis.title=element_text(size=20)),
             ggplot(data_list[[ 8 ]] ,aes(x=value, fill=variable)) + geom_density(alpha=0.25) + ggtitle(" did2 CEA ") + theme(legend.position = "none") + theme(plot.title = element_text(size = 24)) + theme(axis.text=element_text(size=15)) + theme(axis.title=element_text(size=20)),
             ggplot(data_list[[ 9 ]] ,aes(x=value, fill=variable)) + geom_density(alpha=0.25) + ggtitle(" did2 BNST ") + theme(legend.position = "none") + theme(plot.title = element_text(size = 24)) + theme(axis.text=element_text(size=15)) + theme(axis.title=element_text(size=20)),
             ggplot(data_list[[ 10 ]] ,aes(x=value, fill=variable)) + geom_density(alpha=0.25) + ggtitle(" did2 NAC ") + theme(legend.position = "none") + theme(plot.title = element_text(size = 24)) + theme(axis.text=element_text(size=15)) + theme(axis.title=element_text(size=20)),
             ggplot(data_list[[ 11 ]] ,aes(x=value, fill=variable)) + geom_density(alpha=0.25) + ggtitle(" did2 PFC ") + theme(legend.position = "none") + theme(plot.title = element_text(size = 24)) + theme(axis.text=element_text(size=15)) + theme(axis.title=element_text(size=20)),
             ggplot(data_list[[ 12 ]] ,aes(x=value, fill=variable)) + geom_density(alpha=0.25) + ggtitle(" did2 VTA ") + theme(legend.position = "none") + theme(plot.title = element_text(size = 24)) + theme(axis.text=element_text(size=15)) + theme(axis.title=element_text(size=20)),
             ncol = 6)
dev.off()
#head(deout_sub)
#savehistory("pdist.densityplot.Rhistory")
