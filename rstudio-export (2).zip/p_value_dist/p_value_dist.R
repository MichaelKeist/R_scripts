#Example pvalue distribution R script (input is deseq2 csv file)
library(ggplot2)
library(reshape2)
file_vec <- list.files(path = "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value",
                       full.names = TRUE)
count = 1
while(count <= length(file_vec)){
  file = file_vec[count]
  deout<-read.table(file, header=TRUE, sep=",", row.names=1)
  deout<-na.omit(deout)
  deout_sub<-deout[,c("pvalue","padj")]
  data<- melt(deout_sub)
  simple_name <- strsplit(file, "/")
  simple_name <- simple_name[[1]]
  simple_name <- simple_name[length(simple_name)]
  simple_name <- strsplit(simple_name, "\\.")[[1]][1]
  simple_name <- paste(strsplit(simple_name, "_")[[1]][1], strsplit(simple_name, "_")[[1]][2], "pdist.pdf", sep = "_")
  file_loc <- paste("~/p_value_dist/", simple_name, sep="")
  pdf(file_loc)
  #jpeg(filename = paste("~/p_value_dist/", simple_name, sep=""), 
       #width = 8, height = 8, units = "in", quality = 100, 
       #res = 150)
  ggplot(data,aes(x=value, fill=variable)) + geom_density(alpha=0.25)
  ggplot(data,aes(x=value, fill=variable)) + geom_histogram(alpha=0.25)
  dev.off()
  count = count + 1
  
}


#head(deout_sub)
#savehistory("pdist.densityplot.Rhistory")
