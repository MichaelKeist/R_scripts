#!/bin/bash
TARGET_REGION=$"BLA"
GENE_LOC=$"/stor/home/mk37825/BLA_consolidated_lists/"
SCRIPT_LOC=$"/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/scripts/enrichr_scripts/enrichRsetup.R"
OUTPUT_LOC=$"/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/visualizations/enrichr/WGCNA_modules/new/$TARGET_REGION/"
COMMAND_LOC=$"/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/scripts/running_enrichR/${TARGET_REGION}_commands"
for FILE in $GENE_LOC*
do
  SIMPLE_NAME=${FILE##*[0-9]_}
  SIMPLE_NAME=${SIMPLE_NAME%%_*}
  SIMPLE_NAME=$(echo $SIMPLE_NAME | awk '{print "BLA_" $1}')
  echo "Rscript $SCRIPT_LOC -o $OUTPUT_LOC -a $FILE -s $SIMPLE_NAME" >> $COMMAND_LOC
done