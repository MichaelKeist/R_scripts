#!/bin/bash
for FILE in /stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/counts/*.txt
do
  NAME=$(echo "$FILE" | cut -d / -f 8 | cut -d A -f 1 | cut -c 6-)
  echo "$NAME"
  tail -n 92 $FILE | cut -f9 | cut -d';' -f1 | sed 's/gene_id\|"\| //g' > $NAME.gene_id
  tail -n 92 $FILE | cut -f6 > $NAME.raw_count
  tail -n 92 $FILE | cut -f9 | cut -d';' -f3 | sed 's/RPKM\|"\| //g' > $NAME.RPKM
  paste $NAME.gene_id $NAME.raw_count $NAME.RPKM > /stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/ERCC/counts/$NAME.ERCC.counts
  rm $NAME.gene_id $NAME.raw_count $NAME.RPKM
done