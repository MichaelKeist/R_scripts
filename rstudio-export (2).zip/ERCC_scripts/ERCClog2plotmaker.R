library(dplyr)
mix2datatable <- read.csv(file = 'ERCC_mix2_metadata.csv', header = T)
mix2datatable <- mix2datatable[c(-1)]
mix2countstable <- read.csv(file = 'mix2counts.csv')


#FOR MIX2
mix2table <- cbind(mix2datatable, mix2countstable)
logmix2table <- mix2table[, c(10, 25)]

nozeros_logmix2table <- logmix2table %>% filter(log2avg != '-Inf')
colnames(nozeros_logmix2table)[1] <- 'Mix 2 Log2 Concentration'
colnames(nozeros_logmix2table)[2] <- 'Mix 2 Log2 Average Counts'

#set reg to get linear model
reg<-lm(nozeros_logmix2table$`Mix 2 Log2 Average Counts` ~ nozeros_logmix2table$`Mix 2 Log2 Concentration`)
#get rsquared
rsquared <- summary(reg)$r.squared
coeff=coefficients(reg)
summary <- str(summary(reg))
capture.output(summary, file = "mix2log2summary.txt")
# equation of the line : 
#eq = paste0("y = ", round(coeff[2],1), "*x + ", round(coeff[1],1))
#
plot(nozeros_logmix2table)
abline(reg, col="blue")


# for mix 1
mix1datatable <- read.csv(file = 'ERCC_mix1_metadata.csv', header = T)
mix1datatable <- mix1datatable[c(-1)]
mix1countstable <- read.csv(file = 'mix1counts.csv')

mix1table <- cbind(mix1datatable, mix1countstable)
logmix1table <- mix1table[, c(10, 23)]

nozeros_logmix1table <- logmix1table %>% filter(log2avg != '-Inf')
colnames(nozeros_logmix1table)[1] <- 'Mix 1 Log2 Concentration'
colnames(nozeros_logmix1table)[2] <- 'Mix 1 Log2 Average Counts'

#set reg to get linear model
reg<-lm(nozeros_logmix1table$`Mix 1 Log2 Average Counts` ~ nozeros_logmix1table$`Mix 1 Log2 Concentration`)
rsquared1 <- summary(reg)$r.squared
coeff1=coefficients(reg)
summary1 <- summary(reg)
# equation of the line : 
#eq = paste0("y = ", round(coeff[2],1), "*x + ", round(coeff[1],1))
#
summary
plot(nozeros_logmix1table)
abline(reg, col="blue")