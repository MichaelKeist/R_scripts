#import excel table & save to .csv table
library(readxl)
library(dplyr)
my_data <- read_excel("ERCCmix1mix2.xlsx")
#separate for mix1 & mix2
mix1 <- my_data[, c(1:9, 19)]
mix2 <- my_data[, c(1:8, 25, 35)]
#save to .csv table
write.csv(mix1, file = 'ERCC_mix1_metadata.csv')
write.csv(mix2, file = 'ERCC_mix2_metadata.csv')

