#this plot will make a bar chart showing levels of DEGs
library(reshape2)
library(ggplot2)

deseq_files <- list.files(path = "/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value", full.names = TRUE)
sample_names <- list.files("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/DESeq/new_significance_value")
deseq_list <- list()
deg_list <- list()

#looping to get significant genes from each brain region/mouseline
for(i in 1:length(deseq_files)){
  new_element <- read.table(file = deseq_files[i], header = TRUE, sep = ",")
  new_element <- new_element[which(new_element$padj <= 0.05),]
  deseq_list[[i]] <- new_element
  sample_name <- strsplit(sample_names[i], "_")
  sample_name <- paste(sample_name[[1]][1], sample_name[[1]][2],sep = "_")
  names(deseq_list)[i] <- sample_name
}

for(i in 1:length(deseq_list)){
  deg_list[[i]] <- length(deseq_list[[i]]$X)
}
names(deg_list) <- names(deseq_list)
deg_frame <- as.data.frame(deg_list)
deg_frame <- transpose(deg_frame)
rownames(deg_frame) <- names(deg_list)
deg_frame$Region <- c("BLA", "BNST", "CEA", "NAC", "PFC", "VTA", "BLA", "BNST", "CEA", "NAC", "PFC", "VTA")
deg_frame$Line <- c("DID1","DID1","DID1","DID1","DID1","DID1", "DID2","DID2","DID2","DID2","DID2","DID2")
colnames(deg_frame) <- c("DEG_Count", "Brain_Region", "Line")

ggplot(deg_frame, aes(Brain_Region, DEG_Count)) +   
  geom_bar(aes(fill = Line), position = "dodge", stat="identity") + theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  ggtitle("Amounts of Differentially Expressed Genes") + xlab("Brain Region") + ylab("DEG Count") +
  theme(panel.border = element_blank(),
       panel.grid.major = element_blank(),
       panel.grid.minor = element_blank())
  
