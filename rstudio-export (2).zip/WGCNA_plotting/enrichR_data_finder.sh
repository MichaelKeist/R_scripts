#!/bin/bash
FILE_LOC=$"/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/visualizations/enrichr/WGCNA_modules/new"
for FILE in $FILE_LOC/*
do
	for REGION in $FILE/*
	do
		if [[ $REGION =~ .*"KEGG"*. ]]
		then
			for MODULE in $REGION/*
			do
				echo $MODULE
			done	
		fi
	done
done
