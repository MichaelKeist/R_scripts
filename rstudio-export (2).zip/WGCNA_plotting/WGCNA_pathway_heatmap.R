#Creates enrichR pathway heatmaps for WGCNA modules across several brain regions
library(ComplexHeatmap)
library(pheatmap)
library(data.table)
library(enrichplot)
library(enrichR)
library(DOSE)

enrichr_locations <- scan("/stor/work/FRI-BigDataBio/Binge_Drinking_Mice/alternate_pipeline/scripts/WGCNA_plotting/enrichr_results.txt", what = character())

#separate results into groups
separate_group <- function(vector, group){
  output <- as.list(vector[grepl(group, vector)])
  return(output)
}

result_list <- list()
result_list[["BLA_results"]] <- separate_group(enrichr_locations, "BLA")
result_list[["BNST_results"]] <- separate_group(enrichr_locations, "BNST")
result_list[["CEA_results"]] <- separate_group(enrichr_locations, "CEA")
result_list[["NAC_results"]] <- separate_group(enrichr_locations, "NAC")
result_list[["PFC_results"]] <- separate_group(enrichr_locations, "PFC")
result_list[["VTA_results"]] <- separate_group(enrichr_locations, "VTA")

#processing results
for(i in 1:length(result_list)){
  for(j in 1:length(result_list[[i]])){
    result_list[[i]][[j]] <- fread(result_list[[i]][[j]], header = TRUE)
    result_list[[i]][[j]] <- result_list[[i]][[j]][order(Combined.Score, decreasing = TRUE),]
  }
}

#combining module results within each brain region
#and grabbing the NUMPATHWAYS pathways with lowest padj values across modules for each brain region
#ACTUALLY, THE SCRIPT WILL PULL OUT COMBINED SCORES!!

NUMPATHWAYS <- 10
processed_results <- list()
top_count <- 1
for(region in result_list){
  path_count <- 1
  score_count <- 1
  top_pathways <- c()
  scores <- c()
  for(result in region){
    for(pathway in result$Term[1:NUMPATHWAYS]){
      top_pathways[path_count] <- pathway
      path_count <- path_count + 1
    }
    for(score in result$Combined.Score[1:NUMPATHWAYS]){
      scores[score_count] <- score
      score_count <- score_count + 1
    }
  }
  names(scores) <- top_pathways
  processed_results[[names(result_list)[top_count]]] <- sort(scores)[1:NUMPATHWAYS]
  top_count <- top_count + 1
}

#the loop outputs processed_results, which has the top 5 enriched pathways for each region
#now I need to combine the result dataframes across modules within each brain region
#If a pathway is measured in more than one module, I'll choose the lower padj value

top_count <- 1
for(region in result_list){
  combined_count <- 1
  combined_term <- c()
  combined_score <- c()
  for(frame in region){
    for(i in 1:length(rownames(frame))){
      combined_term[combined_count] <- frame$Term[i]
      combined_score[combined_count] <- frame$Combined.Score
      combined_count <- combined_count + 1
    }
  }
  names(combined_score) <- combined_term
  combined_score <- sort(combined_score)
  combined_score <- combined_score[!duplicated(names(combined_score))]
  result_list[[names(result_list)[top_count]]] <- combined_score
  top_count <- top_count + 1
}

#Time to start constructing the heatmap input frame

term_vec <- c()
score_vec <- c()
logged_terms <- c()   #to keep track of already added pathways

term_count <- 1
for(region in processed_results){ #combining terms across brain regions and removing duplicates
  for(term in names(region)){
    term_vec[term_count] <- term
    term_count <- term_count + 1
  }
}
term_vec <- term_vec[!duplicated(term_vec)]

#pulling data for each term for each brain region

getscore <- function(region){ #the function gets -log10 padj
  output <- result_list[[paste(region, "_results", sep = "")]][term_vec]
  return(output)
}

input_frame <- data.frame(BLA = getscore("BLA"), BNST = getscore("BNST"), CEA = getscore("CEA"), NAC = getscore("NAC"),
                          PFC = getscore("PFC"), VTA = getscore("VTA"), row.names = term_vec)
input_frame[is.na(input_frame)] <- 0

pheatmap(input_frame, scale = "row", border_color = F, treeheight_row = 10, treeheight_col = 5, main = "WGCNA Modules Enrichment",
         cluster_cols = F)


